from typing import List, Dict
import json
from utils.llm_utils import call_gemini
from utils.prompt_utils import extract_clean_json

from rich import print as rprint
from rich import print_json

from typing import Optional, Dict

import re

def generate_prompt_for_user_story(text: str) -> str:
    return f"""
    You are an expert Agile Product Owner. Your primary goal is to decompose functional requirements into user stories that adhere to the INVEST principles (Independent, Negotiable, Valuable, Estimable, Small, Testable).

    For each functional requirement provided, perform the following:
    1.  Analyze the requirement. If it is too large to be completed by a single developer in a short timeframe (e.g., a few days), break it down into multiple, smaller, independent user stories. If it cannot be broken down, classify it as an 'Epic'.
    2.  For each resulting user story or epic, generate the following attributes.

    Generate your response as a single, raw JSON array.

    ### JSON OUTPUT STRUCTURE ###
    [
    {{
        "requirement_id": "REQ-001",
        "requirement": {text}
        "confidence_score": 0.95, // Your confidence in understanding and decomposing the requirement correctly.
        "stories": [
        {{
            "story_type": "User Story", // "User Story" or "Epic".
            "user_story": "As a <specific_role>, I want <action>, so that <benefit>.",
            "acceptance_criteria": [
            "Given <precondition>, when <action is performed>, then <expected outcome>.",
            "Given <another precondition>, when <a different action is performed>, then <a different outcome>."
            ],
            "tshirt_size": "M", // Estimated effort: "XS", "S", "M", "L", "XL".
            "questions_for_po": [ // List clarifying questions about ambiguities or missing details.
                "What should happen if the user's session expires during the process?",
                "Are there specific performance requirements for the image upload?"
            ]
        }},
        // ... more user stories if the requirement was decomposed.
        ]
    }},
    // ... more requirement objects
    ]

    ### IMPORTANT INSTRUCTIONS ###
    - **Role Specificity:** Be as specific as possible for the `<role>`. Avoid generic "user" if the context implies a more specific persona (e.g., "site administrator", "unauthenticated visitor").
    - **Acceptance Criteria Format:** All acceptance criteria MUST follow the Gherkin "Given/When/Then" syntax.
    - **Decomposition:** Prioritize creating small, valuable, and independent stories. It is better to have more small stories than one large one.
    - **Output Format:** Respond ONLY with the raw JSON array. Do NOT use Markdown, code fences (```json), or add any explanatory text outside of the JSON structure.

    ### REQUIREMENTS TO PROCESS ###
    {text}

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).
    """.strip()

def extract_user_story(text: str):
    prompt = generate_prompt_for_user_story(text)
    response = call_gemini(prompt=prompt)

    return response

def extract_user_story_from_requirement(requirement: str) -> Dict:
    all_facts = []
    user_story = ""
    
    # Extract facts from requirements
    # req_facts = extract_facts("requirement", entry["requirement"])
    user_story = extract_clean_json(extract_user_story(requirement))

    return user_story

