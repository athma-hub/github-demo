from typing import List, Dict
import json
from utils.llm_utils import call_gemini
from utils.prompt_utils import extract_clean_json

from rich import print as rprint
from rich import print_json

# ORIGINAL PROMPT - to output JSON
"""
        You are an expert business analyst and requirements engineer.

        Extract symbolic facts from the following {input_type}. Focus only on functionality, actor, goal, object, behavior, 
        and system expectations.

        {text}

        Output in this exact JSON format:
        [
            {{ "key": "<fact_type>", "value": "<value>" }},
        ...
        ]

        Rules:
        - Do not repeat facts.
        - Only extract what's explicitly stated or logically required.
        - Do not include formatting or metadata.

        IMPORTANT:
        - Do NOT include triple backticks (```).
        - Do NOT use Markdown.
        - Do NOT add any explanation.
        Return only raw JSON text.
"""

# REFINED PROMPT - to output JSON - use this prompt to use validate_facts() from symbolic_validator.py
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided {input_type}.

    **Focus your extraction exclusively on the following semantic categories:**
    * **Actor:** The user or external system interacting with the system.
    * **Goal:** The desired outcome or objective of an actor or the system.
    * **Object:** The data, entity, or resource manipulated or acted upon by the system.
    * **Behavior:** The actions, operations, or processes performed by the system or an actor.
    * **System Expectation (Functional):** What the system *must do* in terms of its functionality.
    * **System Expectation (Non-Functional - if applicable and explicitly stated):** Constraints or quality attributes like performance, security, usability, etc., *only if directly stated as a system requirement.*

    **Input:**
    {text}

    **Output Format:**
    Produce a JSON array of objects, where each object represents a distinct fact. Adhere strictly to the following structure:
    ```json
    [
        {{ "key": "<fact_type>", "value": "<extracted_value>" }},
        {{ "key": "<fact_type>", "value": "<extracted_value>" }},
        ...
    ]

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw JSON text.
    """

# REFINED PROMPT - to output Prolog-style logic facts compatible with PyReason.
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided {input_type} and represent 
    them as Prolog-style logic facts compatible with PyReason.

    **Focus your extraction exclusively on the following semantic categories:**
    * **Actor:** The user or external system interacting with the system. Represent as `actor(actor_name)`.
    * **Goal:** The desired outcome or objective of an actor or the system. Represent as `goal(actor_name, goal_description)`.
    * **Object:** The data, entity, or resource manipulated or acted upon by the system. Represent as `object(object_name)`.
    * **Behavior:** The actions, operations, or processes performed by the system or an actor. Represent as `behavior(actor_or_system_name, action_description, object_name)`.
    * **System Expectation (Functional):** What the system *must do* in terms of its functionality. Represent as `system_functional_expectation(system_component, expected_behavior, object_name)`.
    * **System Expectation (Non-Functional - if applicable and explicitly stated):** Constraints or quality attributes like performance, security, usability, etc., *only if directly stated as a system requirement.* Represent as `system_non_functional_expectation(system_component, attribute, value)`.
    * **Relationship:** Any explicit relationship between extracted entities. Represent as `has_relationship(entity1, relationship_type, entity2)`.

    **Input:**
    {text}

    **Output Format:**
    Produce a series of Prolog-style logic facts, one per line. Each fact must end with a period (`.`).
    Strictly adhere to the predicate names and argument order specified in the semantic categories above.

    Example:

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """

# REFINED PROMPT - to compatible with Experta
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided text, 
    categorizing them by their source {input_type}, and representing them as Prolog-style logic facts compatible with PyReason.

    **Output Predicates:**
    * `requirement_fact(Key, Value).` - Use this predicate for facts extracted from the "Requirement" section.
    * `user_story_fact(Key, Value).` - Use this predicate for facts extracted from the "User Story" section.
    * `acceptance_criteria_fact(Key, Value).` - Use this predicate for facts extracted from the "Acceptance Criteria" section.

    **Focus your extraction exclusively on the following semantic categories, which will serve as the `Key` in your facts:**
    * **actor:** The user or external system interacting with the system.
        * **Value Format:** `'actor_name'` (e.g., `'customer'`)
    * **goal:** The desired outcome or objective of an actor or the system.
        * **Value Format:** `'actor_or_system_goal_description'` (e.g., `'customer_spread_cost_over_time'`)
    * **object:** The data, entity, or resource manipulated or acted upon by the system.
        * **Value Format:** `'object_name'` (e.g., `'school_fee_payment'`)
    * **behavior:** The actions, operations, or processes performed by the system or an actor.
        * **Value Format:** `'actor_or_system_performs_action_on_object'` (e.g., `'customer_converts_school_fee_payment'`)
    * **system_functional_expectation:** What the system *must do* in terms of its functionality.
        * **Value Format:** `'system_component_performs_expected_behavior_on_object'` (e.g., `'system_enables_conversion_of_payments'`)
    * **system_non_functional_expectation:** Constraints or quality attributes (e.g., performance, security, usability), *only if directly stated as a system requirement.*
        * **Value Format:** `'system_component_has_attribute_value'` (e.g., `'system_has_response_time_less_than_1_second'`)
    * **relationship:** Any explicit relationship between extracted entities.
        * **Value Format:** `'entity1_relationship_type_entity2'` (e.g., `'order_includes_product'`)

    **Input:**
    {text}

    **Output Format:**
    Produce a series of Prolog-style logic facts, one per line. Each fact must end with a period (`.`).
    Strictly adhere to the predicate names (`requirement_fact`, `user_story_fact`, `acceptance_criteria_fact`), the specified `Key` atoms, and the `Value` formatting.

    **Strict Extraction Rules:**
    1.  **Explicitness and Logical Implication:** Only extract facts that are directly and explicitly stated in the input, or those that are unequivocally logically implied by the explicit statements. Avoid inferring beyond what is clearly presented.
    2.  **No Redundancy:** Each extracted fact must be unique. Do not repeat facts even if they are mentioned multiple times.
    3.  **No Interpretation or Summarization:** Do not interpret, summarize, or rephrase the facts. The `Key` must be one of the predefined semantic categories. The `Value` should be a descriptive, single-quoted atom derived from the original wording, ensuring it is lowercase with underscores (`_`) replacing spaces.
    4.  **No External Information:** Do not introduce any information or knowledge not contained within the provided input text.
    5.  **Strict Category Adherence:** Ensure each extracted fact accurately maps to one of the specified semantic categories (`Key`). If a piece of information does not fit, it should not be extracted.
    6.  **Granularity:** Extract facts at a granular level. Break down complex sentences into multiple atomic facts, ensuring each `Value` clearly encapsulates a single piece of information related to its `Key`.
    7.  **Atom Naming:** All predicate names (`requirement_fact`, etc.), `Key` atoms (e.g., `actor`, `goal`), and components within the `Value` (when constructing multi-word atoms) must be in lowercase. Use underscores (`_`) to separate words. All `Value` arguments must be enclosed in single quotes (e.g., `'customer_account'`).
    8.  **Fact Termination:** Every fact must end with a period (`.`).

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """

def generate_prompt_for_facts(input_type: str, text: str) -> str:
    return f"""
    You are an expert requirements engineer with a deep understanding of semantic analysis and knowledge representation. 
    Your task is to act as a Natural Language Understanding (NLU) engine, meticulously extracting structured, multi-argument, 
    Prolog-style logic facts from the provided text, categorizing them by their source ```{input_type}```

    **Core Task:**
    Deconstruct each sentence from the Requirement, User Story, and Acceptance Criteria into its fundamental semantic components. 
    Represent these components as structured facts with multiple arguments.

    **Output Predicate Structures:**
    You must use the following predicate structures. Do not invent new ones.

    1.  **For Requirements (REQ):**
        * `requirement(object, ReqID, ObjectName).`
            * e.g., `requirement(object, 'REQ-xxx', 'school_fee_payment').`
        * `requirement(relationship, ReqID, Entity1, Verb, Entity2).`
            * e.g., `requirement(relationship, 'REQ-xxx', 'school_fee_payment', 'converts_to', 'easy_payment_plan').`

    2.  **For User Stories (US):**
        * `user_story(actor, StoryID, ActorName).`
            * e.g., `user_story(actor, 'US-1', 'customer').`
        * `user_story(goal, StoryID, GoalDescription).`
            * e.g., `user_story(goal, 'US-1', 'spread_cost_over_time').`
        * `user_story(action, StoryID, Actor, Verb, DirectObject, PrepositionalObject).`
            * *Actor:* Who performs the action.
            * *Verb:* The action being performed.
            * *DirectObject:* The entity being acted upon.
            * *PrepositionalObject:* The target/destination of the action (often follows 'to' or 'into'). Use 'null' if not present.
            * e.g., `user_story(action, 'US-1', 'customer', 'convert', 'school_fee_payment', 'easy_payment_plan').`

    3.  **For Acceptance Criteria (AC):**
        * `acceptance_criterion(system_action, AcID, Agent, Verb, Patient).`
            * *Agent:* Who performs the action (usually 'system').
            * *Verb:* The action being performed.
            * *Patient:* The entity being acted upon.
            * e.g., `acceptance_criterion(system_action, 'AC-3', 'system', 'convert', 'payment').`
        * `acceptance_criterion(system_state, AcID, Entity, StateDescription).`
            * *Entity:* The object or component.
            * *StateDescription:* The expected state or property.
            * e.g., `acceptance_criterion(system_state, 'AC-1', 'epp_option', 'is_available_during_fee_payment_process').`

    **Strict Extraction & Normalization Rules:**
    1.  **Structure Adherence:** Strictly follow the predicate structures defined above.
    2.  **Normalization:**
        * **Verbs:** Normalize verbs to their base form (e.g., "converts," "conversion" -> "convert"; "enables" -> "enable"; "displays" -> "display").
        * **Nouns:** Use a consistent name for an entity. Normalize acronyms to their full form (e.g., "EPP" -> "easy_payment_plan"; "epp_option" -> "easy_payment_plan_option").
    3.  **IDs:** Use the provided IDs (`REQ-001`, `US-1`, `AC-1`, etc.) in every fact.
    4.  **Granularity:** Break each sentence into one or more structured facts.
    5.  **Atom Naming:** All predicate names, types, and values must be lowercase, use underscores for spaces, and be enclosed in single quotes where appropriate.
    6.  **Termination:** Every fact must end with a period (`.`).

    **Input Text:**
    ```{text}```

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """.strip()

def extract_prolog_style_facts(input_type: str, text: str):
    prompt = generate_prompt_for_facts(input_type, text)
    response = call_gemini(prompt=prompt)

    return response

def extract_facts(input_type: str, text: str) -> List[Dict[str, str]]:
    prompt = generate_prompt_for_facts(input_type, text)
    response = call_gemini(prompt=prompt)

    try:
        llm_results = extract_clean_json(response)
    except Exception as e:
        llm_results = []
    
    return llm_results

def extract_facts_for_entry(entry: Dict) -> Dict:
    all_facts = []
    prolog_facts = ""
    
    # Extract facts from requirements
    # req_facts = extract_facts("requirement", entry["requirement"])
    req_facts = extract_prolog_style_facts("requirement", entry["requirement"])
    prolog_facts += req_facts
    # all_facts.extend([{"source": "requirement", **f} for f in req_facts]) # use this if JSON

    # Extract facts from user story and acceptance criteria for each user story
    # story_facts = extract_facts("user story", entry["user_story"])
    for story in entry.get("stories", []):
        story_facts = extract_prolog_style_facts("user story", story["user_story"])
        prolog_facts += story_facts
        # all_facts.extend([{"source": "user_story", **f} for f in story_facts]) # use this if JSON

        # Extract from each acceptance criterion
        for ac in story.get("acceptance_criteria", []):
            # ac_facts = extract_facts("acceptance criteria", ac)
            ac_facts = extract_prolog_style_facts("acceptance criteria", ac)
            prolog_facts += ac_facts
            # all_facts.extend([{"source": "acceptance_criteria", **f} for f in ac_facts])  # grouped under user story facts

    """ return {
        "requirement_id": entry["requirement_id"],
        "facts": all_facts
    } """ # use this if working with JSON

    return prolog_facts

