import json
from rich import print as rprint
from rich import print_json as jprint

from fact_extractor import extract_facts_for_entry
from req_to_us import extract_user_story_from_requirement
from requirement_extractor import load_md_tool, extract_requirements_from_md, preprocess_md_tool
from feedback_implementor import incorporate_nesy_feedback, check_extracted_facts_with_feedback_incorporates

from validate_experta import *
from symbolic_validator_semantic import *

OUTPUT = "prolog"

def extract_facts(validated = False):
    rprint("[bold magenta] Output for REQ-001 [/bold magenta]")
    """ 
    req = {
        "requirement_id": "REQ-001",
        "requirement": "Enable conversion of school fee payments to Easy Payment Plan (EPP).",
        "user_story": "As a customer, I want to convert my school fee payment into an Easy Payment Plan (EPP), so that I can spread the cost over time.",
        "acceptance_criteria": [
            "An option to convert to EPP is available during the fee payment process.",
            "EPP terms and conditions are clearly displayed.",
            "The system successfully converts the payment to EPP."
        ]
    } 

    req = {
        "requirement_id": "REQ-002",
        "requirement": "Customers with NGB credit cards can pay school fees through Online banking, Mobile banking, IVR, and E-Form (via Contact Center agent).",
        "user_story": "As a customer, I want to pay school fees using my NGB credit card through Online banking, Mobile banking, IVR, and E-Form, so that I can conveniently pay school fees.",
        "acceptance_criteria": [
            "School fee payments are possible via Online banking, Mobile banking, IVR, and E-Form.",
            "Payments can be made using NGB credit cards.",
            "Successful payment confirmation is provided to the customer."
        ]
    }        

    req = {
        "requirement_id": "REQ-008",
        "requirement": "Enable student registration, amendment, and de-registration via Online banking, Mobile banking, and Contact center (using E-Form).",
        "user_story": "As a customer, I want to register, amend, and de-register students via Online banking, Mobile banking, and Contact center, so that I can manage my children's school registrations conveniently.",
        "acceptance_criteria": [
            "Student registration, amendment, and de-registration are available through Online banking, Mobile banking, and Contact center (E-Form).",
            "Successful operation confirmation is provided to the customer.",
            "The system maintains an accurate record of student registrations."
        ]
    }
    """

    # latest structure for the extracted user stories
    """ requirements = [
        {
            "requirement_id": "REQ-002",
            "requirement": "The system shall allow the Product team to send school registration data via email in Excel format.",
            "confidence_score": 0.95,
            "stories": [
                {
                    "story_type": "User Story",
                    "user_story": "As a Product team member, I want to be able to prepare school registration data in an Excel file, so that I can easily organize and manage the data before sending it.",
                    "acceptance_criteria": [
                    "Given I have school registration data, when I create an Excel file, then the data is correctly formatted and organized in the file."
                    ],
                    "tshirt_size": "S",
                    "questions_for_po": [
                    "What is the required format of the Excel file (column names, data types, etc.)?",
                    "Are there any specific templates or guidelines for preparing the Excel file?"
                    ]
                },
                {
                    "story_type": "User Story",
                    "user_story": "As a Product team member, I want to be able to attach an Excel file to an email, so that I can send the school registration data to the intended recipient.",
                    "acceptance_criteria": [
                    "Given I have an Excel file containing school registration data, when I attach it to an email, then the attachment is successfully added to the email.",
                    "Given the email is sent, when I check the recipient's inbox, then the email with the attachment is received."
                    ],
                    "tshirt_size": "S",
                    "questions_for_po": [
                    "What email client should be used for testing?",
                    "Are there any size limitations for the attached Excel file?"
                    ]
                },
                {
                    "story_type": "User Story",
                    "user_story": "As a Product team member, I want the system to send an email notification when the school registration data has been successfully sent, so that I'm informed of successful delivery.",
                    "acceptance_criteria": [
                    "Given an email with an attached Excel file is successfully sent, when the email is successfully delivered, then the system sends a notification to the sender confirming successful delivery."
                    ],
                    "tshirt_size": "XS",
                    "questions_for_po": [
                    "What type of notification is required (e.g., email, in-app notification)?",
                    "What information should the notification include?"
                    ]
                }
            ]
        }
    ] """

    # read the content of the extracted user stories and convert to JSON for easy handling
    if validated:
        with open("extracted_user_story_feedback_incorporated.json", "r") as f:
            content = f.read()
    else:
        with open("extracted_user_story.json", "r") as f:
            content = f.read()

    requirements = json.loads(content)

    # Extract facts
    result = ""
    for req in requirements:
        result += extract_facts_for_entry(req)

    # print_json(json.dumps(result, indent=2))
    if OUTPUT == "prolog":
        if validated:
            with open("extracted_facts_after_validation.txt", "w") as f:
                f.write(result)
                # json.dump(result, f, indent=2)
        else:
            with open("extracted_facts.txt", "w") as f:
                f.write(result)
        
        rprint(f"[bold green]Extracted facts from requirement, user stories and acceptance criteria written to extracted_facts.txt [/bold green]")
    elif OUTPUT == "json":
        with open("extracted_facts.json", "w") as f:
            json.dump(result, f, indent=2)

        rprint(f"[bold green]Code summary written to output_extracted_facts.json [/bold green]")
    

def validate_facts_experta():
    # Validate
    engine = RequirementsValidatorV4()
    engine.reset()
    engine.run()

    print("\n" + "="*50)
    print("      STRUCTURED REQUIREMENTS COVERAGE REPORT")
    print("="*50 + "\n")

    # --- This entire reporting block is new and robust ---

    # 1. Create a lookup map of all facts by their unique ID
    fact_lookup = {f['__factid__']: f for f in engine.facts.values()}

    # 2. Get the unique IDs of ALL requirement facts
    all_req_ids = {f['__factid__'] for f in fact_lookup.values() if isinstance(f, Requirement)}

    # 3. Get the unique IDs of the COVERED requirement facts
    covered_req_ids = {
        f['req_fact']['__factid__']
        for f in fact_lookup.values() if isinstance(f, CoveredRequirement)
    }

    # 4. Perform the set difference on the IDs - this is now 100% reliable
    uncovered_req_ids = all_req_ids - covered_req_ids

    # 5. Print the report using the lookup map for readable output

    print(f"--- ✅ Covered Requirements ({len(covered_req_ids)}) ---")
    if not covered_req_ids:
        print("None.")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_covered = sorted([fact_lookup[fid] for fid in covered_req_ids], key=str)
        for req in sorted_covered:
             print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + f"--- ❌ Uncovered Requirements (Gaps) ({len(uncovered_req_ids)}) ---")
    if not uncovered_req_ids:
        print("None. All requirements have been covered!")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_uncovered = sorted([fact_lookup[fid] for fid in uncovered_req_ids], key=str)
        for req in sorted_uncovered:
            print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + "="*50)

def validate_facts_semantically(validated = False):
    output = convert_facts_to_flat_json("FR010", validated)
    jprint(json.dumps(output, indent=2))
    
    fact_entry = output

    """ 
    # Example extracted facts from BRD, user story, and acceptance criteria
    fact_entry = {
        "requirement_id": "REQ-001",
        "facts": [
            # Requirements
            {"source": "requirement", "key": "object", "value": "school_fee_payment"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through online_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through mobile_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through ivr"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through e_form"},
            {"source": "requirement", "key": "relationship", "value": "e_form via contact_center_agent"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment available_to customers_with_ngb_credit_cards"},

            # User story
            {"source": "user_story", "key": "actor", "value": "customer"},
            {"source": "user_story", "key": "goal", "value": "conveniently_pay_school_fees"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees online_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees mobile_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees ivr"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees e_form"},
            {"source": "user_story", "key": "action", "value": "contact_center_agent process e_form"},
            {"source": "user_story", "key": "action", "value": "customer use ngb_credit_card"},

            # Acceptance criteria
            {"source": "acceptance_criteria", "key": "system_action", "value": "system provide payment_confirmation"},
            {"source": "acceptance_criteria", "key": "system_action", "value": "system send payment_confirmation customer"},
        ]
    }
    """
    # Run semantic validation
    result = validate_facts(fact_entry)

    # Display results
    print("\n🔎 Validation Result")
    print("=====================")
    print(f"📌 Requirement ID: {result['requirement_id']}")
    print(f"✅ Overall Valid: {result['valid']}")

    print("\n✅ Valid Facts:")
    if result["valid_facts"]:
        for fact in result["valid_facts"]:
            print(" -", fact)
    else:
        print(" (none)")

    print("\n❌ Missing Facts:")
    if result["missing_facts"]:
        for fact in result["missing_facts"]:
            print(" -", fact)
    else:
        print(" (none)")

    # Optional: Export to JSON file

    if validated:
        with open("validation_result_after_feedback_incorporated.json", "w") as f:
            json.dump(result, f, indent=1)
    else:
        with open("validation_result.json", "w") as f:
            json.dump(result, f, indent=1)

    print("\n📄 Validation summary exported to 'validation_result.json'")

def check_incorporated_feedback(requirement: str):
    inputs = {
        "requirement_text": requirement,
        "feedback_incorporated_user_story": "extracted_user_story_feedback_incorporated.json",
        "extracted_facts": "extracted_facts.txt",
    }
    result = check_extracted_facts_with_feedback_incorporates(inputs=inputs)
    rprint(f"[bold green]{result}[/bold green]")

def incorporate_feedback(requirement: str):
    inputs = {
        "requirement_text": requirement,
        "extracted_user_story": "extracted_user_story.json",
        "extracted_facts": "extracted_facts.txt",
        "validation_result": "validation_result.json"
    }
    result = incorporate_nesy_feedback(inputs=inputs)
    jprint(json.dumps(result, indent=2))

    with open("extracted_user_story_feedback_incorporated.json", "w") as f:
        json.dump(result, f, indent=2)

    rprint(f"[bold green]NeSy Feedback incorporated user stories written to to output_extracted_facts.json [/bold green]")

def extract_requirements(file_path: str, pre_process=False):
    # Extract requirements from the SRS / BRD .md file
    if pre_process: 
        preprocess_md_tool({"file_path": file_path})

    result = load_md_tool({"file_path": "BRD_NGB_Preprocessed.md"})
    requirements = extract_requirements_from_md({"raw_text": result["raw_text"]})

    with open("extracted_requirements.json", "w") as f:
        json.dump(requirements, f, indent=2)

    rprint(f"[bold green]Code summary written to output_extracted_facts.json [/bold green]")

    # return requirements

def extract_us(text: str):
    # Extract facts
    result = extract_user_story_from_requirement(text)
    jprint(json.dumps(result, indent=2))

    with open("extracted_user_story.json", "w") as f:
        json.dump(result, f, indent=2)

    rprint(f"[bold green]User stories written to extracted_user_story.json [/bold green]")

def read_extracted_requirements(file_path = "extracted_requirements.json"):
    # read the content of the extracted user stories and convert to JSON for easy handling
    with open("extracted_requirements.json", "r") as f:
        content = f.read()

    extracted_requirements = json.loads(content)
    for entry in extracted_requirements:
        functional_requirements = entry["Functional Requirements"]
        rprint(functional_requirements)

if __name__ == "__main__":
    # read_extracted_requirements()
    # extract_requirements("BRD_NGB.md")
    # extract_us("System shall send an SMS to the customer during student registration, amendment, or de-registration.")
    # extract_facts(validated=False)
    # validate_facts_semantically(validated=False)
    # incorporate_feedback("System shall send an SMS to the customer during student registration, amendment, or de-registration.")    
    # extract_facts(validated=True) # this approach is not required
    # validate_facts_semantically(validated=True) # this approach is not required
    check_incorporated_feedback("System shall send an SMS to the customer during student registration, amendment, or de-registration.")