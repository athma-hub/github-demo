"""
GOAL
---------
Check whether all critical requirement facts are preserved in either the user story or the acceptance criteria.
Do this using semantic similarity instead of exact matches, via a hybrid Experta + Sentence Transformers approach.
"""

import collections
import collections.abc
collections.Mapping = collections.abc.Mapping

from experta import Fact, KnowledgeEngine, Rule, DefFacts
from typing import List, Dict
from sentence_transformers import SentenceTransformer, util

from rich import print as rprint
from rich import print_json as jprint
import json
import re
from collections import defaultdict

# Load sentence transformer model
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
# model = SentenceTransformer('all-MiniLM-L6-v2')

# Threshold for semantic match
SIMILARITY_THRESHOLD = 0.65
ENABLE_DEBUG_LOGGING = True  # Set to False to disable cosine score logging

def normalize_fact_string(key: str, value: str) -> str:
    """
    Turn a structured fact into a natural-language-like string.
    """
    key = key.replace("_", " ")
    value = value.replace("_", " ").replace("-", " ").strip()
    return f"{key}: {value}"

def facts_semantically_similar(fact_str: str, reference_facts: List[str], threshold: float = SIMILARITY_THRESHOLD) -> bool:
    """
    Check if `fact_str` is semantically similar to any of the reference facts.
    """
    emb1 = model.encode(fact_str, convert_to_tensor=True)
    emb2 = model.encode(reference_facts, convert_to_tensor=True)
    cosine_scores = util.cos_sim(emb1, emb2)
    
    if ENABLE_DEBUG_LOGGING:
        print(f"\n🔍 Checking: {fact_str}")
        for ref_str, score in zip(reference_facts, cosine_scores[0]):
            print(f"  → Score with '{ref_str}': {score:.4f}")

    return any(score >= threshold for score in cosine_scores[0])

# Wrapper Fact for use in Experta
class FactWrapper(Fact):
    pass

# Knowledge Engine
class SemanticValidatorEngine(KnowledgeEngine):

    def __init__(self, fact_entry: Dict):
        super().__init__()
        self.requirement_id = fact_entry["requirement_id"]
        self.requirement_facts = [f for f in fact_entry["facts"] if f["source"] == "requirement"]
        self.other_facts = [f for f in fact_entry["facts"] if f["source"] in ("user_story", "acceptance_criteria")]
        self.justifications = []
        self.valid_facts = []

    @DefFacts()
    def _load_facts(self):
        for fact in self.other_facts:
            yield FactWrapper(key=fact["key"], value=fact["value"])

    @Rule()
    def validate_semantically(self):
        """
        Use sentence embeddings to match requirement facts against user stories and acceptance criteria.
        """
        comparison_strings = [normalize_fact_string(f["key"], f["value"]) for f in self.other_facts]

        for req in self.requirement_facts:
            fact_str = normalize_fact_string(req["key"], req["value"])
            if facts_semantically_similar(fact_str, comparison_strings):
                self.valid_facts.append(fact_str)
            else:
                self.justifications.append(f"Missing or semantically unmatched: {fact_str}")

    def get_validation_result(self) -> Dict:
        return {
            "requirement_id": self.requirement_id,
            "valid": len(self.justifications) == 0,
            "valid_facts": self.valid_facts,
            "missing_facts": self.justifications,
            "justification": self.justifications
        }

# Public function to run validation
def validate_facts(fact_entry: Dict) -> Dict:
    engine = SemanticValidatorEngine(fact_entry)
    engine.reset()
    engine.run()
    return engine.get_validation_result()

def parse_fact_line(line):
    line = line.strip().rstrip(".")
    if not line:
        return None

    # Pattern: predicate(arg1, arg2, ..., argN)
    match = re.match(r"(\w+)\((.*)\)", line)
    if not match:
        return None

    predicate, args_str = match.groups()
    args = [arg.strip().strip("'") for arg in args_str.split(",")]

    # Remove ID (usually at index 1), we don't need it in value 
    # value at 1 is type or predicate and args[1] is ID
    value_args = args[2:] if len(args) > 2 else []

    if predicate == "requirement":
        if args[0] == "object":
            return {"source": "requirement", "key": "object", "value": args[2]}
        elif args[0] == "relationship":
            return {"source": "requirement", "key": "relationship", "value": f"{args[2]} {args[3]} {args[4]}"}

    elif predicate == "user_story":
        if args[0] == "actor":
            return {"source": "user_story", "key": "actor", "value": args[2]}
        elif args[0] == "goal":
            return {"source": "user_story", "key": "goal", "value": args[2]}
        elif args[0] == "action":
            po = args[5] if args[5] != "null" else ""
            return {"source": "user_story", "key": "action", "value": f"{args[2]} {args[3]} {args[4]} {po}".strip()}

    elif predicate == "acceptance_criterion":
        if args[0] == "system_action":
            return {"source": "acceptance_criteria", "key": "system_action", "value": f"{args[2]} {args[3]} {args[4]}"}
        elif args[0] == "system_state":
            return {"source": "acceptance_criteria", "key": "system_state", "value": f"{args[2]} {args[3]}"}

    return None

def convert_facts_to_flat_json(requirement_id: str = "REQ-001") -> dict:
    filename = "extracted_facts.txt"
    rprint(f"[italic green] INFO: Loading facts from '{filename}' [/italic green]")    

    all_facts = []
    try:
        with open(filename, 'r') as f:
            for line in f:
                # Sanitize the line: remove leading/trailing whitespace
                line = line.strip()
                # <-- 2. ADDED LINE: Remove the tag using a regular expression
                line = re.sub(r'^\\s*', '', line)

                if not line or line.startswith('%') or line.startswith('#'):
                    continue
                
                parsed = parse_fact_line(line)
                if parsed:
                    all_facts.append(parsed)
            
            return {
                "requirement_id": requirement_id,
                "facts": all_facts
            }

    except FileNotFoundError:
        print(f"[italic red] ERROR: Fact file '{filename}' not found. Please create it. [/italic red]")
        print("[italic red] HINT: The script will now exit. Please create the file and run again. [/italic red]")

if __name__ == "__main__":
    output = convert_facts_to_flat_json("REQ-001")
    jprint(json.dumps(output, indent=2))
    
    fact_entry = output

    """ 
    # Example extracted facts from BRD, user story, and acceptance criteria
    fact_entry = {
        "requirement_id": "REQ-001",
        "facts": [
            # Requirements
            {"source": "requirement", "key": "object", "value": "school_fee_payment"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through online_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through mobile_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through ivr"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through e_form"},
            {"source": "requirement", "key": "relationship", "value": "e_form via contact_center_agent"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment available_to customers_with_ngb_credit_cards"},

            # User story
            {"source": "user_story", "key": "actor", "value": "customer"},
            {"source": "user_story", "key": "goal", "value": "conveniently_pay_school_fees"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees online_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees mobile_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees ivr"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees e_form"},
            {"source": "user_story", "key": "action", "value": "contact_center_agent process e_form"},
            {"source": "user_story", "key": "action", "value": "customer use ngb_credit_card"},

            # Acceptance criteria
            {"source": "acceptance_criteria", "key": "system_action", "value": "system provide payment_confirmation"},
            {"source": "acceptance_criteria", "key": "system_action", "value": "system send payment_confirmation customer"},
        ]
    }
    """
    # Run semantic validation
    result = validate_facts(fact_entry)

    # Display results
    print("\n🔎 Validation Result")
    print("=====================")
    print(f"📌 Requirement ID: {result['requirement_id']}")
    print(f"✅ Overall Valid: {result['valid']}")

    print("\n✅ Valid Facts:")
    if result["valid_facts"]:
        for fact in result["valid_facts"]:
            print(" -", fact)
    else:
        print(" (none)")

    print("\n❌ Missing Facts:")
    if result["missing_facts"]:
        for fact in result["missing_facts"]:
            print(" -", fact)
    else:
        print(" (none)")

    # Optional: Export to JSON file
    with open("validation_result.json", "w") as f:
        json.dump(result, f, indent=1)

    print("\n📄 Validation summary exported to 'validation_result.json'")