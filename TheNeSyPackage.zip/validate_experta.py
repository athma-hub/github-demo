"""
line-by-line explanation of the final validate_experta_v4.py script, designed for anyone new to understand from start to finish.

High-Level Purpose of the Script
This script acts as an automated requirements coverage validator. Its job is to answer the question: 
"Are all the requirements defined in our specification covered by at least one user story or acceptance criterion?"

It does this using the experta Python library to build a simple expert system. An expert system is a program that uses 
logical rules to reason about a set of facts, much like a human expert would.

The script operates in three main stages:
Defining the Data Structures: Creating templates for our facts (e.g., what does a "requirement" look like?).
Defining the Reasoning Logic: Creating "IF-THEN" rules that determine when a requirement is covered.
Execution and Reporting: Loading the data, running the reasoning engine, and printing a clear report of the results.
"""

import collections
import collections.abc
collections.Mapping = collections.abc.Mapping

from experta import *
from rich import print as rprint

import sys
import re # <-- 1. IMPORT THE REGULAR EXPRESSION MODULE

from experta import *

"""
Part 1: Defining the Data Structures (The Fact Classes)
Facts are the individual pieces of information that our system knows. We define a "blueprint" or "template" for 
each type of information by creating a Python class that inherits from Experta's Fact.
"""
# --- Structured Fact Definitions with __str__ for readable output ---

# Defines a general category for facts that are requirements. This allows us to easily group different 
# types of requirements later. It inherits from Fact so the engine recognizes it.
class Requirement(Fact):
    """A base class for all requirement facts."""
    req_id = Field(str, mandatory=True) #  Declares that every Requirement fact must have a field named req_id that holds a string value.

# This defines the blueprint for a fact about a required object (e.g., "the system must handle a school_fee_payment"). 
# It inherits the req_id field.
class ReqObject(Requirement):
    """A required object."""
    name = Field(str, mandatory=True)

    def __str__(self):
        # This controls how the fact is printed
        # This f-string constructs the clean output we see in the final report, 
        # like ReqObject(req_id='REQ-001', name='school_fee_payment').
        return f"ReqObject(req_id='{self.get('req_id')}', name='{self.get('name')}')"

# This follows the exact same pattern, defining the structure and readable format for facts about required relationships.
class ReqRelationship(Requirement):
    """A required relationship."""
    entity1 = Field(str, mandatory=True)
    verb = Field(str, mandatory=True)
    entity2 = Field(str, mandatory=True)

    def __str__(self):
        # This controls how the fact is printed
        return f"ReqRelationship(req_id='{self.get('req_id')}', entity1='{self.get('entity1')}', verb='{self.get('verb')}', entity2='{self.get('entity2')}')"

# --- Other Fact classes (no changes needed) ---
class UserStoryActor(Fact):
    us_id = Field(str, mandatory=True)
    name = Field(str, mandatory=True)
class UserStoryGoal(Fact):
    us_id = Field(str, mandatory=True)
    description = Field(str, mandatory=True)
class UserStoryAction(Fact):
    us_id = Field(str, mandatory=True)
    actor = Field(str, mandatory=True)
    verb = Field(str, mandatory=True)
    object = Field(str, mandatory=True)
    target = Field(str, mandatory=True)
class ACSystemAction(Fact):
    ac_id = Field(str, mandatory=True)
    agent = Field(str, mandatory=True)
    verb = Field(str, mandatory=True)
    patient = Field(str, mandatory=True)
    target = Field(str, default='null')
class ACSystemState(Fact):
    ac_id = Field(str, mandatory=True)
    entity = Field(str, mandatory=True)
    state = Field(str, mandatory=True)

# This defines the blueprint for a "receipt" or "marker" fact. When a rule decides a requirement has been covered, 
# it will create one of these facts.
class CoveredRequirement(Fact):
    """
    A fact to mark a requirement as covered.
    We only define the simple string field. The other fields ('req_fact')
    will hold a fact object and are added dynamically to avoid an internal
    Experta validation error.
    """
    req_id = Field(str, mandatory=True)

# --- FACT_DISPATCHER (remains the same) ---
FACT_DISPATCHER = {
    ('requirement', 'object'): (ReqObject, ['req_id', 'name']),
    ('requirement', 'relationship'): (ReqRelationship, ['req_id', 'entity1', 'verb', 'entity2']),
    ('user_story', 'actor'): (UserStoryActor, ['us_id', 'name']),
    ('user_story', 'goal'): (UserStoryGoal, ['us_id', 'description']),
    ('user_story', 'action'): (UserStoryAction, ['us_id', 'actor', 'verb', 'object', 'target']),
    ('acceptance_criterion', 'system_action'): (ACSystemAction, ['ac_id', 'agent', 'verb', 'patient', 'target']),
    ('acceptance_criterion', 'system_state'): (ACSystemState, ['ac_id', 'entity', 'state']),
}

"""
Part 2: The Reasoning Logic (The KnowledgeEngine Class)

This class is the "brain" of the operation. It holds the facts and the rules for reasoning about them.

class RequirementsValidatorV4(KnowledgeEngine):: Defines our main engine, inheriting all the reasoning power from 
Experta's KnowledgeEngine.

@DefFacts(): This decorator tells the engine to run this method automatically when it starts (engine.reset()) 
to load the initial facts into its memory.

yield ReqObject(...): Each yield creates a fact object using the blueprints we defined earlier and adds it to 
the engine's list of known facts.
"""
# --- The Knowledge Engine (no changes needed) ---
class RequirementsValidatorV4(KnowledgeEngine):
    @DefFacts()
    def load_structured_facts(self):
        """ # Facts loaded from your provided list
        yield ReqObject(req_id='REQ-001', name='school_fee_payment')
        yield ReqObject(req_id='REQ-001', name='easy_payment_plan_option')
        yield ReqRelationship(req_id='REQ-001', entity1='school_fee_payment', verb='convert', entity2='easy_payment_plan')
        yield ReqRelationship(req_id='REQ-001', entity1='easy_payment_plan_option', verb='is_available_during', entity2='fee_payment_process')
        yield UserStoryActor(us_id='US-1', name='customer')
        yield UserStoryGoal(us_id='US-1', description='convert_school_fee_payment_to_easy_payment_plan')
        yield UserStoryGoal(us_id='US-1', description='spread_cost_over_time')
        yield UserStoryAction(us_id='US-1', actor='customer', verb='convert', object='school_fee_payment', target='easy_payment_plan')
        yield ACSystemAction(ac_id='AC-1', agent='system', verb='convert', patient='school_fee_payment')
        yield ACSystemState(ac_id='AC-1', entity='easy_payment_plan_option', state='is_available_during_fee_payment_process')
        yield ACSystemAction(ac_id='AC-1', agent='system', verb='display', patient='epp_terms_and_conditions')
        yield ACSystemState(ac_id='AC-1', entity='epp_terms_and_conditions', state='are_clearly_displayed')
        yield ACSystemAction(ac_id='AC-1', agent='system', verb='convert', patient='payment')
        yield ACSystemState(ac_id='AC-1', entity='payment', state='converted_to_easy_payment_plan')
        yield ACSystemAction(ac_id='AC-2', agent='system', verb='enable', patient='easy_payment_plan_conversion') """
        # --- MODIFIED: The method now handles the tags from the file ---
        """
        Dynamically loads facts from an external file 'extracted_facts.lp'.
        This method parses each line and yields the corresponding Fact object.
        """
        filename = "extracted_facts.txt"
        rprint(f"[italic green] INFO: Loading facts from '{filename}' [/italic green]")

        try:
            with open(filename, 'r') as f:
                for line in f:
                    # Sanitize the line: remove leading/trailing whitespace
                    line = line.strip()

                    # <-- 2. ADDED LINE: Remove the tag using a regular expression
                    line = re.sub(r'^\\s*', '', line)
                    
                    if not line or line.startswith('%') or line.startswith('#'):
                        continue

                    try:
                        predicate, args_str = line[:-1].split('(', 1)
                        args_str = args_str.rsplit(')', 1)[0]
                        args = [arg.strip().strip("'") for arg in args_str.split(',')]
                        fact_type = args[0]
                        dispatch_key = (predicate, fact_type)
                        
                        if dispatch_key in FACT_DISPATCHER:
                            FactClass, field_names = FACT_DISPATCHER[dispatch_key]
                            kwargs = dict(zip(field_names, args[1:]))
                            yield FactClass(**kwargs)
                        else:
                            print(f"[italic red] WARNING: No dispatcher found for key {dispatch_key}. Skipping line: {line} [/italic red]")

                    except ValueError as e:
                        print(f"[italic red] WARNING: Could not parse line: {line}. Error: {e} [/italic red]")
        
        except FileNotFoundError:
            print(f"[italic red] ERROR: Fact file '{filename}' not found. Please create it. [/italic red]")
            print("[italic red] HINT: The script will now exit. Please create the file and run again. [/italic red]")
            sys.exit(1)

    """
    The Coverage Rules
    Rules are "IF-THEN" statements. If all the "IF" conditions are met by the facts in memory, the "THEN" action is performed.

    Rule 1: cover_object_by_action
    @Rule(...): Defines the "IF" conditions of the rule.

    'f1' << ReqObject(...): This is Condition 1: Find a required object.
        'f1' <<: This is the syntax to bind an entire matched Fact object to an internal variable. The variable name, 'f1', 
        must be a string literal.
        ReqObject(...): This is the pattern to match.
        req_id=MATCH.rid: Inside the pattern, MATCH is used to capture a field's value. Here, the req_id is captured into the variable rid.

    NOT(CoveredRequirement(req_fact=MATCH.f1)): This is Condition 2: Make sure it's not already covered.
        NOT(...): This pattern must not be found in memory.
        req_fact=MATCH.f1: This precisely checks if a receipt already exists for the exact fact object we just bound to 'f1'. 
        This prevents the rule from firing repeatedly on the same covered requirement.

    (UserStoryAction(...) | ...): This is Condition 3: Find covering evidence.
        |: The pipe symbol means OR. The rule succeeds if any of these patterns match. It looks for the object's name in a 
        UserStoryAction or an ACSystemAction.

    salience=10: This gives the rule a priority of 10. Rules with higher numbers fire first.

    def cover_object_by_action(self, rid, f1):: This is the "THEN" action. The variables captured (rid, f1) are passed as 
    arguments.

    self.declare(CoveredRequirement(...)): This is the action itself. self.declare adds a new fact to memory. We create our 
    CoveredRequirement receipt, storing a reference to the fact (f1) that was just validated.
    """

    @Rule(
        'f1' << ReqObject(req_id=MATCH.rid, name=MATCH.name),
        NOT(CoveredRequirement(req_fact=MATCH.f1)),
        (UserStoryAction(object=MATCH.name) | UserStoryAction(target=MATCH.name) | ACSystemAction(patient=MATCH.name)),
        salience=10
    )
    def cover_object_by_action(self, rid, f1):
        self.declare(CoveredRequirement(req_id=rid, req_fact=f1))

    """
    Rule 2 (cover_relationship_by_action_or_state) follows the same principles but has more complex OR conditions to 
    find evidence for a relationship in actions or system states.
    """
    @Rule(
        'f2' << ReqRelationship(req_id=MATCH.rid, entity1=MATCH.e1, verb=MATCH.v, entity2=MATCH.e2),
        NOT(CoveredRequirement(req_fact=MATCH.f2)),
        OR(
            UserStoryAction(verb=MATCH.v, object=MATCH.e1, target=MATCH.e2),
            ACSystemAction(verb=MATCH.v, patient=P(lambda p: p in [MATCH.e1, 'payment']), target=MATCH.e2),
            AND(
                ACSystemState(entity=MATCH.e1, state=MATCH.state_val),
                TEST(lambda v, state_val: v in state_val)
            )
        )
    )
    def cover_relationship_by_action_or_state(self, rid, f2):
        self.declare(CoveredRequirement(req_id=rid, req_fact=f2))


# --- Main Execution Block with FINAL Reporting Logic ---
if __name__ == "__main__":
    engine = RequirementsValidatorV4()
    engine.reset()
    engine.run()

    print("\n" + "="*50)
    print("      STRUCTURED REQUIREMENTS COVERAGE REPORT")
    print("="*50 + "\n")

    # --- This entire reporting block is new and robust ---

    # 1. Create a lookup map of all facts by their unique ID
    fact_lookup = {f['__factid__']: f for f in engine.facts.values()}

    # 2. Get the unique IDs of ALL requirement facts
    all_req_ids = {f['__factid__'] for f in fact_lookup.values() if isinstance(f, Requirement)}

    # 3. Get the unique IDs of the COVERED requirement facts
    covered_req_ids = {
        f['req_fact']['__factid__']
        for f in fact_lookup.values() if isinstance(f, CoveredRequirement)
    }

    # 4. Perform the set difference on the IDs - this is now 100% reliable
    uncovered_req_ids = all_req_ids - covered_req_ids

    # 5. Print the report using the lookup map for readable output

    print(f"--- ✅ Covered Requirements ({len(covered_req_ids)}) ---")
    if not covered_req_ids:
        print("None.")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_covered = sorted([fact_lookup[fid] for fid in covered_req_ids], key=str)
        for req in sorted_covered:
             print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + f"--- ❌ Uncovered Requirements (Gaps) ({len(uncovered_req_ids)}) ---")
    if not uncovered_req_ids:
        print("None. All requirements have been covered!")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_uncovered = sorted([fact_lookup[fid] for fid in uncovered_req_ids], key=str)
        for req in sorted_uncovered:
            print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + "="*50)