# tools/extractor_tools.py
from typing import Dict, List

from utils.llm_utils import call_gemini
from utils.prompt_utils import extract_clean_json

def preprocess_md_tool(inputs: Dict, lines_per_page=50) -> Dict:
    """
    Loads a .md file and preprocesses the md file to add linenumbers and page numbers. Saves it back as proprocessed md file
    """
    file_path = inputs["file_path"]
    numbered_brd = ""
    current_page = 1
    current_line_nr = 1

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if i % lines_per_page == 0:
                numbered_brd += "".join(f"\n--- Page {current_page} ---\n")
                current_page += 1
            if line == "\n": # add line numbers to only lines with text else ignore and add as is
                numbered_brd += "".join(f"{line.strip()}")
            else:
                numbered_brd += "".join(f"[Line {current_line_nr:03}] {line.strip()}\n")
                current_line_nr += 1
                
    
    with open("BRD_NGB_Preprocessed.md", "w", encoding="utf-8") as f:
        f.write(numbered_brd)

def load_md_tool(inputs: Dict) -> Dict:
    """
    Loads a .md file and returns its raw text.
    """
    file_path = inputs["file_path"]
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    return {"raw_text": text}

def generate_prompt_for_requirement_extraction(SRS: str) -> str:
    return f"""
    You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
    functional and any non-functional requirements that are needed to build the system.

    Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
        - Functional Requirements (FR)
        - Non-Functional Requirements (NFR)
        - Business Rules (BR)
        - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
        - Other Observations (repetitions, conflicts, missing modules)

    Generate your response as a single, raw JSON array.

    ---
    ### SRS Document:
    ```{SRS}```

    ---

    ### JSON OUTPUT STRUCTURE ###
    [
        {{
            **Functional Requirements**
            [
                {{
                    "requirement_id": "FR001",
                    "requirement_text": "System shall allow students to reset their password via email",
                    "original_text": "The student should be able to change their password using a reset link sent to their registered email.",
                    "source_section": "3.2.1",
                    "page_number": 5,
                    "line_number": 142
                }},
            ]

            **Non-Functional Requirements**
            [
                {{
                    "requirement_id": "NFR001",
                    "requirement_text": "System should maintain 99.9% uptime over a calendar month.",
                    "original_text": "The system should always be available and must have 99.9% uptime.",
                    "source_section": "4.1.1",
                    "page_number": 8,
                    "line_number": 207
                }},
            ]

            **Business Rules**
            [
                {{
                    "requirement_id": "BR001",
                    "requirement_text": "A student can register for a maximum of 5 courses per semester.",
                    "original_text": "Students are not allowed to enroll in more than 5 courses each semester.",
                    "source_section": "3.4",
                    "page_number": 6,
                    "line_number": 178
                }},
            ]

            **Ambiguous or Subjective Requirements (Needs Clarification)**
            [
                {{
                    "requirement_id": "Q001",
                    "requirement_text": "System should be user-friendly",
                    "original_text": "The system should be user-friendly and visually pleasing.",
                    "reason": "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria.",
                    "source_section": "5.2.1",
                    "page_number": 9,
                    "line_number": 222
                }},
            ]

            **Other_Observations**
            [
                {{
                    "observation_id": "OBS001",
                    "observation_text": "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB.",
                    "page_number": 7,
                    "line_number": 192
                }},
            ]
        }}
    ]

    ### Guidelines:
        - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
        - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
        - Keep requirement descriptions concise and clear.  
        - Include source_section, page_number, and line_number where available for traceability.
        - Try to include the SRS section number (if available) for traceability.
        - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
        - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
        - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.
        - For each requirement, return a "confidence_score" between 0 and 1 (e.g., 0.95) reflecting how confidently this is a valid requirement from the SRS.
        - Identify the primary stakeholders impacted by or responsible for the requirement. Return them in a "stakeholders" array. Possible stakeholders include:
            - Customer
            - End-user
            - Admin
            - DevOps
            - Compliance Officer
            - Legal
            - Operations
            - Product Owner
            - API Partner
            - Contact Center Agent
        - You may list multiple stakeholders if applicable.
        - Confidence should reflect clarity, phrasing, and alignment with standard requirement definitions.
        - If a requirement is vague or inferred but still extracted, assign a lower confidence score (e.g., < 0.7).
        - Stakeholders should reflect *who will use, implement, or be impacted by* the requirement.       
    
    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).
    """.strip()

def extract_requirements(file_content: str):
    prompt = generate_prompt_for_requirement_extraction(file_content)
    response = call_gemini(prompt=prompt)

    return response

def extract_requirements_from_md(inputs: Dict):
    # Step 1: First get the requirement text in whole
    raw_text = inputs["raw_text"]

    requirements = extract_clean_json(extract_requirements(raw_text))

    return requirements