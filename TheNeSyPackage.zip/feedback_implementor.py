from typing import List, Dict
import json
from utils.llm_utils import call_gemini
from utils.prompt_utils import extract_clean_json

from rich import print as rprint
from rich import print_json

from typing import Optional, Dict

import re

def generate_prompt_for_checking_feedback_incorporation(inputs: Dict) -> str:
    return f"""
    You are an expert in requirement validation and structured fact extraction from Agile user stories.

    ## Context

    You are provided with:
    1. A **requirement** from a Business Requirements Document (BRD),
    2. A list of **Prolog-style extracted facts** from the requirement and the corresponding user stories with acceptance criteria,
    3. A set of **user stories and acceptance criteria** that attempt to capture the requirement.

    ---
    ### Requirement
    {inputs["requirement_text"]}

    ---
    ### Prolog-style extracted facts
    {inputs["facts_text"]}


    ---
    ### User Stories and Acceptance Criteria (JSON)
    {json.dumps(inputs["feedback_incorporated_user_story_text"], indent=2)}

    ---
    ### Task

    1. Compare the **requirement facts** with the facts represented in the **user stories and acceptance criteria**.
    2. Identify any **requirement facts that are missing or not semantically represented** in the user stories or acceptance criteria.
    3. Return **only the missing facts** in Prolog-style syntax. Use the following conventions:
    - `requirement(object, 'FR004', '...')`
    - `requirement(relationship, 'FR004', 'A', 'REL', 'B')`
    - `user_story(actor|goal|action, 'US-1', ...)`
    - `acceptance_criterion(system_state|system_action, 'AC-1', ...)`
    4. Ensure values are lowercase with underscores (`bus_fee` instead of `'Bus Fee'`).
    5. Do **not** repeat facts that are already present in the extracted facts list.
    6. Do **not** return explanations—just the new facts in this format:
        requirement(object, 'FR004', 'system').
        requirement(relationship, 'FR004', 'system', 'provide', 'option').

    Only return facts that are **missing or semantically unmatched** from the requirement and not represented in the 
    user stories or their acceptance criteria.

    If there are no facts that are **missing or semantically unmatched** return the message 
    "All requirement facts have been represented in either the user stories or acceptance criteria"

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
    """.strip()

def generate_prompt_for_feedback_incorporation(inputs: Dict) -> str:
    return f"""
    You are an expert in software requirement engineering and agile user story refinement.

    Inputs:
    1. Requirement:
    {inputs["requirement_text"]}

    2. Extracted User Stories (JSON):
    {json.dumps(inputs["user_story_text"], indent=2)}

    3. Validation Results (JSON):
    {json.dumps(inputs["validation_result_text"], indent=2)}

    4. Extracted Facts (plaintext):
    {inputs["facts_text"]}

    ---

    Objective:
    Ensure that _all_ requirement facts appear in at least one user story or its acceptance criteria. If any fact is 
    missing (flagged as missing in Validation Results), modify the existing user stories—either the story text or 
    acceptance criteria—to include the missing fact. Do **not** add new stories unless absolutely necessary for coverage. 
    Preserve intent and scope of original stories.

    Instructions:
    • Identify which facts are missing according to validation results.
    • For each missing fact, integrate it into the most appropriate existing story or its acceptance criteria.
    • Avoid duplicating or inventing facts beyond what's needed.
    • Maintain the structure and metadata for each story: user story text, acceptance criteria, tshirt size, questions_for_po.
    • Output the **full** updated JSON with all original stories (modified as needed), matching this format exactly:

    [  
        {{  
            "requirement_id": "REQ‑XXX",  
            "requirement": "…",  
            "confidence_score": 0.Y,  
            "stories": [  
                {{  
                    "user_story": "As a …, I want to … so that …",  
                    "acceptance_criteria": [ "…" ],  
                    "tshirt_size": "S|M|L|XL",  
                    "questions_for_po": [ "…" ]  
                }},  
                … 
            ]  
        }}  
    ]

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).
    """.strip()

def load_file_content(file_path: str, key_value: str) -> Dict:
    """
    Loads a .md file and returns its raw text.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    return {key_value: text}

def incorporate_nesy_feedback(inputs: Dict) -> Dict:
    all_contents = {"requirement_text": inputs["requirement_text"]}

    all_contents.update(load_file_content(inputs["extracted_user_story"], key_value="user_story_text"))
    all_contents.update(load_file_content(inputs["extracted_facts"], key_value="facts_text"))
    all_contents.update(load_file_content(inputs["validation_result"],key_value="validation_result_text"))

    prompt = generate_prompt_for_feedback_incorporation(all_contents)
    response = call_gemini(prompt=prompt)
    user_story = extract_clean_json(response)

    return user_story

def check_extracted_facts_with_feedback_incorporates(inputs: Dict) -> Dict:
    all_contents = {"requirement_text": inputs["requirement_text"]}

    all_contents.update(load_file_content(inputs["feedback_incorporated_user_story"],key_value="feedback_incorporated_user_story_text"))
    all_contents.update(load_file_content(inputs["extracted_facts"], key_value="facts_text"))

    prompt = generate_prompt_for_checking_feedback_incorporation(all_contents)
    response = call_gemini(prompt=prompt)

    return response