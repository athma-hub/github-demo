"""
GOAL
---------
Check whether all critical requirement facts are preserved in either the user story or the acceptance criteria.
If any fact is missing, we:
    - Need to Flag it
    - Explain it
    - and Provide a validation report
"""
from typing import List, Dict

"""
implement simple rule-based validation logic, but it is not yet using PyReason. This is a custom Python set-difference evaluator.
"""
def validate_facts(fact_entry: Dict) -> Dict:
    
    req_id = fact_entry["requirement_id"]
    facts = fact_entry["facts"]

    # collect facts by source
    requirement_facts = set((f["key"], f["value"]) for f in facts if f["source"] == "requirement")
    user_story_facts = set((f["key"], f["value"]) for f in facts if f["source"] == "user_story")
    ac_criteria_facts = set((f["key"], f["value"]) for f in facts if f["source"] == "user_story")

    # Combine user story and A/C for validation
    combined_facts = user_story_facts.union(ac_criteria_facts)

    # Identify missing requirement facts
    missing = requirement_facts - combined_facts

    # Build justification
    justification = []
    for k, v in missing:
        justification.append(f"Missing fact: {k} = {v} not found in user story or acceptance criteria.")

    return {
        "requirement_id": req_id,
        "valid": len(missing) == 0,
        "missing_facts": list(missing),
        "justification": justification
    }

