

from utils.llm_utils import call_gemini
from utils.prompt_utils import extract_clean_json

from rich import print_json as jprint
from rich import print as rprint

from facts_rules import UserStory, JustificationEngine

'''
'rules': [
    'IF the BRD specifies allowing registration of school details AND the user story describes registering school details 
    THEN the user story directly addresses the BRD requirement.',
    'IF the acceptance criteria includes system allowing registration, secure storage, and NGB validation AND these are all        
    necessary for successful school detail registration THEN confidence in the user story is high.',
    "IF the user story's outcome (correct fee payment) is a direct consequence of successfully registering school details 
    THEN the user story is well-defined and its confidence is high."
]
'''

def extract_facts_and_rules_gemini(brd_text: str, user_story_text: str, acceptance_criteria: str = "") -> dict:
    prompt_template = f"""
        You are an expert requirement analyst and symbolic reasoner.

        Given a requirement from a BRD and a user story derived from it, extract:
        1. Structured symbolic facts (actor, action, instrument, channels, constraints, outcome).
        2. Inference rules that explain why the confidence score for this user story is high.

        --- BRD ---
        {brd_text}

        --- User Story ---
        {user_story_text}

        --- Acceptance Criteria ---
        {acceptance_criteria}

        --- Output Format ---
        {{
        "requirement_id": "REQ-xxx",
        "entities": {{
            "actor": "customer",
            "action": "pay_school_fees",
            "instrument": "ngb_credit_card",
            "channels": ["online_banking", "mobile_banking", "ivr", "e_form"],
            "constraints": ["only_ngb_credit_card"],
            "outcome": "payment_confirmed"
        }},
        "rules": [
            "rule_1",
            "rule_2",
            ...
        ]
        }}

        IMPORTANT:
        - Do NOT include triple backticks (```).
        - Do NOT use Markdown.
        - Do NOT add any explanation.
        Return only raw JSON text.
    """

    response = call_gemini(prompt=prompt_template)
    return response

def run_justification_engine(facts_dict):
    engine = JustificationEngine()
    engine.reset()

    entities = facts_dict["entities"]

    engine.declare(UserStory(
        id=facts_dict.get("requirement_id"),
        actor=entities.get("actor"),
        action=entities.get("action"),
        instrument=entities.get("instrument"),
        channels=entities.get("channels", []),
        constraints=entities.get("constraints", []),
        outcome=entities.get("outcome")
    ))

    engine.run()
    
if __name__ == "__main__":
    rprint("[bold magenta] Output for REQ-001 [/bold magenta]")
    req_001 = {
        "requirement_id": "REQ-001",
        "entities": {
            "actor": "customer",
            "action": "pay_school_fees",
            "instrument": "ngb_credit_card",
            "channels": ["online_banking", "mobile_banking", "ivr", "e_form"],
            "constraints": ["only_ngb_credit_card"],
            "outcome": "payment_confirmed"
        }
    }
    run_justification_engine(req_001)

    rprint("[bold magenta] Output for REQ-002 [/bold magenta]")
    req_002 = {
        "requirement_id": "REQ-002",
        "entities": {
            "actor": "customer",
            "action": "convert_to_epp",
            "instrument": "school_fee_transaction",
            "channels": ["online_banking", "mobile_banking"],
            "constraints": ["epp_option_during_payment", "terms_must_be_displayed"],
            "outcome": "epp_conversion_successful"
        }
    }
    run_justification_engine(req_002)

'''
    brd = "Allow student registration, amendment, and de-registration via Online banking, Mobile Banking, and Contact center (using E-Form)."
    story = "As a customer, I want to register, amend, and de-register my student(s) via Online banking, Mobile Banking, and Contact center, so that I can manage my children's school information efficiently."
    criteria = """
    Student registration, amendment, and de-registration are possible through Online banking, Mobile Banking, and Contact Center.
    The system provides confirmation messages after each action.
    Data validation ensures data accuracy.
    """
    
    result = extract_facts_and_rules_gemini(brd, story, criteria)
    llm_results = extract_clean_json(result)

    rprint(llm_results)
'''
