"""

Define the Knowledge Engine
Define a class ConfidenceJustifier using experta.KnowledgeEngine. This engine will:
    - Accept facts about the user story (e.g., channels, actor, constraints).
    - Match them against rules.
    - Output justifications for why the confidence score is high.(this is the explainability)

This is the architecture approach we will follow
BRD + User Story
      │
      ▼
Gemini LLM (with structured prompt)
      │
      ▼
Extracted Symbolic Facts + Rules (JSON format)
      │
      ▼
Rule Generator (Python Template Engine)
      │
      ▼
experta / PyReason Reasoning Engine
      │
      ▼
Human-readable Justification + Traceable Confidence


"""

import collections
import collections.abc
collections.Mapping = collections.abc.Mapping

from experta import *

from rich import print as rprint

class UserStory(Fact):
    """Fact representing structured user story from Gemini output"""
    pass

class JustificationEngine(KnowledgeEngine):

    @Rule(UserStory(actor='customer'))
    def actor_customer(self):
        print("✅ Actor: Story involves the customer")

    @Rule(UserStory(action='pay_school_fees'))
    def action_payment(self):
        print("✅ Action: User intends to pay school fees")

    @Rule(UserStory(action='convert_to_epp'))
    def action_epp(self):
        print("✅ Action: User intends to convert payment to Easy Payment Plan (EPP)")

    @Rule(UserStory(instrument='ngb_credit_card'))
    def instrument_card(self):
        print("✅ Instrument: NGB credit card is used for payment")

    @Rule(UserStory(instrument='school_fee_transaction'))
    def instrument_fee_txn(self):
        print("✅ Instrument: School fee payment is used as basis for EPP")

    @Rule(UserStory(outcome='payment_confirmed'))
    def outcome_payment(self):
        print("✅ Outcome: Payment process is successful and confirmed")

    @Rule(UserStory(outcome='epp_conversion_successful'))
    def outcome_epp(self):
        print("✅ Outcome: EPP conversion process is successful")

    @Rule(UserStory(channels=MATCH.channels))
    def check_channels(self, channels):
        if set(channels) == {"online_banking", "mobile_banking", "ivr", "e_form"}:
            print("✅ Channels: All required payment channels are covered")
        else:
            print(f"✅ Channels: Supports {', '.join(channels)}")

    @Rule(UserStory(constraints=MATCH.constraints))
    def check_constraints(self, constraints):
        for constraint in constraints:
            if constraint == "only_ngb_credit_card":
                print("✅ Constraint: Only NGB credit cards are accepted")
            elif constraint == "epp_option_during_payment":
                print("✅ Constraint: EPP option is available during payment")
            elif constraint == "terms_must_be_displayed":
                print("✅ Constraint: EPP terms are shown to customer")
            else:
                print(f"✅ Constraint: {constraint.replace('_', ' ')}")

'''
{
    'requirement_id': 'REQ-001',
    'entities': {
        'actor': 'customer',
        'action': ['register_student', 'amend_student_details', 'deregister_student'],
        'instrument': ['online_banking', 'mobile_banking', 'e_form'],
        'channels': ['online_banking', 'mobile_banking', 'contact_center'],
        'constraints': ['data_validation'],
        'outcome': ['successful_registration', 'successful_amendment', 'successful_deregistration', 'confirmation_message']
    },
    'rules': [
        'IF (BRD specifies student registration, amendment, and de-registration) AND (User Story requests the same functionalities via 
Online banking, Mobile Banking, and Contact center) AND (Acceptance Criteria confirms successful operations via specified channels)    
THEN (Confidence score is high)',
        "IF (User story goal is efficient management of children's school information) AND (BRD allows actions that directly support   
this goal) THEN (Confidence score is high)",
        'IF (Acceptance Criteria includes data validation and confirmation messages) THEN (Confidence score is high)'
    ]
}
'''