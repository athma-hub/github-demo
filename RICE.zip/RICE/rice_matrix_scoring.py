"""
3-step approach. The key is to standardize the measures before you combine them.

A 3-Step Approach
The core challenge is this: How do you mathematically combine "Account Revenue" (a value in the millions) with 
"Partner Status" (a score from 1 to 5)? You can't just multiply them by weights and add them together. It's an 
"apples and oranges" problem.

Step 1: Standardize Each Individual Measure (The "Apples-to-Apples" Step)
The Problem: Your 15+ measures for each element are on different scales. Direct End-Users might be 50,000, while 
Sponsor Influence is 4. A single large-value measure can dominate the entire calculation, even if its weight is small.

The Solution: Before anything else, convert every single measure for every customer onto a common, 
consistent scale (e.g., 1 to 10). This process is called standardization.

Do this in two main ways:
    Binning (for quantitative data): Define brackets for raw numbers.
        Example for Account Revenue (RCH06):
            - < $500k = Score of 1
            - $500k - $2M = Score of 4
            - $2M - $10M = Score of 7
            - $10M = Score of 10

    Direct Mapping (for qualitative data): The 1-5 scores can be mapped to the 1-10 scale.
        Example for Partner Status (CNF09):
            - A score of 1 -> Standardized Score of 2
            - A score of 3 -> Standardized Score of 6
            - A score of 5 -> Standardized Score of 10

After this step, every single measure for every customer is a score between 1 and 10. The "apples and oranges" problem is solved.

Step 2: Assign Weights and Calculate a Composite Score (The "Importance" Step)
The Problem: Now that all measures are on the same 1-10 scale, we know they won't mathematically distort each other. 
However, they are not all equally important to the business strategy.

The Solution: This is where we apply weights. Assign a weight to each standardized measure, ensuring the weights for all 
measures within one element (e.g., all 15 for Impact) sum to 1.0. Then, calculate a single Composite Score for each 
RICE element for each customer.

The formula is a weighted average:
Composite Score(element) = ∑( Standardized Score (measure) * Weight (measure) )
Example for Customer A's "Impact" Score:
    - Standardized score for Direct Cost Savings = 9/10; Weight = 0.4
    - Standardized score for PR & Brand Value = 5/10; Weight = 0.1
    - ... (and so on for all 15 measures) ...
    - Composite Impact Score (Customer A) = (9 * 0.4) + (5 * 0.1) + ... = 7.8 (for example)

After this step, we will have one composite score (on a 1-10 scale) for Reach, one for Impact, one for Confidence, 
and one for Effort for each customer.

Step 3: Normalize Composite Scores (The "Level Playing Field" Step)
The Problem: Even after Step 2, the range of composite scores might differ between elements. For instance, 
our composite "Reach" scores across all customers might range from 6.5 to 9.0, while your "Confidence" scores 
might range from 4.0 to 7.5. To make the final RICE formula (R × I × C) / E mathematically sound, all four 
elements must be compared on the exact same final scale.

The Solution: Use Min-Max Normalization to stretch or shrink the range of composite scores for each element onto a final, 
uniform scale, like 1 to 100.

We apply this formula to the set of composite scores for each element:

Normalized Score=1+( ((Composite Score - Min Composite Score) / (Max Composite Score - Min Composite Score)) * 99
    -   Min/Max Composite Score refers to the minimum and maximum scores for that specific element across all your customers.

After this final step, Reach, Impact, Confidence, and Effort are all on a 1-100 scale, making the final RICE calculation fair, 
accurate, and reliable. This revised three-step process is more robust and ensures your prioritization is not accidentally 
skewed by the nature of your raw data.
"""
import pandas as pd
import numpy as np

# --- CONFIGURATION: DEFINE WEIGHTS (Strategic Business Decision) ---
# The weights for each RICE element's measures must sum to 1.0.
# NOTE: For this example, I've only listed a few measures per element for brevity.
# In your real implementation, you would list all 15+ measures and their weights.
weights = {
    'Reach': {
        'RCH01': 0.4, 'RCH06': 0.4, 'RCH03': 0.2, # Sum = 1.0
    },
    'Impact': {
        'IMP01': 0.5, 'IMP02': 0.3, 'IMP12': 0.2, # Sum = 1.0
    },
    'Confidence': {
        'CNF01': 0.3, 'CNF02': 0.3, 'CNF09': 0.4, # Sum = 1.0
    },
    'Effort': {
        'EFF01': 0.5, 'EFF05': 0.5, # Sum = 1.0
    }
}


# --- SAMPLE RAW DATA FOR 3 CUSTOMERS ---
# This data is on different scales (counts, dollars, 1-5 scores).
raw_data = {
    'CustomerID': ['Customer A', 'Customer B', 'Customer C'],
    # Reach Measures
    'RCH01': [5000, 500, 12000],        # Direct End-Users (raw count)
    'RCH06': [2000000, 500000, 3500000],# ARR (dollars)
    'RCH03': [5, 2, 8],                  # Departments (raw count)
    # Impact Measures (scored 1-5 by a human)
    'IMP01': [5, 3, 4],                  # Direct Cost Savings
    'IMP02': [2, 4, 4],                  # New Revenue Generation
    'IMP12': [2, 5, 3],                  # 'Get in the Door' Opportunity
    # Confidence Measures (scored 1-5 by a human)
    'CNF01': [5, 3, 4],                  # Sponsor Influence
    'CNF02': [3, 4, 5],                  # Data Quality
    'CNF09': [4, 2, 5],                  # Partner Status
    # Effort Measures
    'EFF01': [12, 4, 24],                # Person-Months (raw count)
    'EFF05': [8, 3, 9],                  # Technical Complexity (scored 1-10)
}
raw_df = pd.DataFrame(raw_data)


def standardize_measures(df):
    """
    STEP 1: Standardize all raw measures to a common 1-10 scale.
    This is the 'Apples-to-Apples' step.
    """
    std_df = pd.DataFrame()
    std_df['CustomerID'] = df['CustomerID']

    # --- Standardize Reach Measures ---
    # Binning for quantitative data like user counts
    std_df['RCH01'] = pd.cut(df['RCH01'], bins=4, labels=[1, 4, 7, 10], include_lowest=True)
    std_df['RCH06'] = pd.cut(df['RCH06'], bins=4, labels=[1, 4, 7, 10], include_lowest=True)
    std_df['RCH03'] = pd.cut(df['RCH03'], bins=3, labels=[1, 5, 10], include_lowest=True)

    # --- Standardize Impact Measures ---
    # Mapping for pre-scored data (e.g., 1-5 scale) to a 1-10 scale
    for col in ['IMP01', 'IMP02', 'IMP12']:
        std_df[col] = 1 + ((df[col] - 1) / 4) * 9

    # --- Standardize Confidence Measures ---
    for col in ['CNF01', 'CNF02', 'CNF09']:
        std_df[col] = 1 + ((df[col] - 1) / 4) * 9
        
    # --- Standardize Effort Measures ---
    # Higher effort values should result in a higher score on the 1-10 scale
    std_df['EFF01'] = pd.cut(df['EFF01'], bins=4, labels=[1, 4, 7, 10], include_lowest=True)
    # This one is already 1-10, so we can use it directly
    std_df['EFF05'] = df['EFF05']
    
    # Convert all columns to numeric, just in case
    for col in std_df.columns:
        if col != 'CustomerID':
            std_df[col] = pd.to_numeric(std_df[col])

    return std_df


def calculate_rice_scores_refined(raw_df, weights):
    """
    Calculates RICE scores using the refined 3-step methodology.
    """
    # STEP 1: Standardize all raw measures to a common 1-10 scale
    std_df = standardize_measures(raw_df)
    
    # STEP 2: Calculate a single Composite Score for each RICE element
    composite_df = pd.DataFrame()
    composite_df['CustomerID'] = std_df['CustomerID']
    
    for element, element_weights in weights.items():
        composite_col_name = f'Composite_{element}'
        composite_df[composite_col_name] = 0
        for measure_col, weight in element_weights.items():
            composite_df[composite_col_name] += std_df[measure_col] * weight
            
    # STEP 3: Normalize the Composite Scores to a 1-100 scale
    norm_df = composite_df.copy()
    for element in weights.keys():
        composite_col = f'Composite_{element}'
        norm_col = f'Norm_{element}'
        
        min_val = norm_df[composite_col].min()
        max_val = norm_df[composite_col].max()
        
        if max_val == min_val:
            norm_df[norm_col] = 50.0 # Assign a neutral middle score
        else:
            norm_df[norm_col] = 1 + ((norm_df[composite_col] - min_val) / (max_val - min_val)) * 99

    # --- FINAL RICE CALCULATION ---
    norm_df['RICE_Score'] = (norm_df['Norm_Reach'] * norm_df['Norm_Impact'] * norm_df['Norm_Confidence']) / norm_df['Norm_Effort']
    
    # Sort by the final RICE score to get the ranking
    final_df = norm_df.sort_values(by='RICE_Score', ascending=False)
    
    return final_df

# --- RUN THE ENTIRE WORKFLOW ---
final_scores_df = calculate_rice_scores_refined(raw_df, weights)

# --- DISPLAY THE FINAL, RANKED RESULTS ---
display_cols = [
    'CustomerID', 
    'Norm_Reach', 
    'Norm_Impact', 
    'Norm_Confidence', 
    'Norm_Effort', 
    'RICE_Score'
]

print("--- Final RICE Scores and Ranking ---")
print(final_scores_df[display_cols].round(2))