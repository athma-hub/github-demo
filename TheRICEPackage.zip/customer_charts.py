import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path
import plotly.express as px
import plotly.io as pio

OUT_DIR = Path("./output")

def generate_heatmap_chart(rice_df, category_name):
    HEATMAP_PNG = OUT_DIR / f"{category_name}_rice_heatmap.png"
    plt.figure(figsize=(10, 6))
    sns.set_style("whitegrid")
    heat_ax = sns.heatmap(
        rice_df.set_index("ID")[["Log_Normalized_RICE_Score"]],
        cmap="YlGnBu",
        annot=True,
        fmt=".2f",
        linewidths=0.5,
        cbar_kws={"label": "RICE Priority"}
    )

    heat_ax.set_title("RICE-Based Heatmap of Customer for AI Interventions", fontsize=14, pad=14)
    heat_ax.set_xlabel("Computed Logarithmic RICE Score", fontsize=11)
    heat_ax.set_ylabel(f"{category_name}", fontsize=11)
    plt.tight_layout()
    plt.savefig(HEATMAP_PNG, dpi=300)
    plt.close()
    print(f"[+] Heatmap saved ➤ {HEATMAP_PNG.resolve()}")

def generate_bar_chart(rice_df, category_name):
    BARCHART_PNG = OUT_DIR / f"{category_name}_rice_bar_chart.png"
    plt.figure(figsize=(10, 6))
    bar_ax = sns.barplot(
        x="Log_Normalized_RICE_Score",
        y="ID",
        hue="ID",
        data=rice_df,
        palette="YlGnBu_r",  # reverse to align color with descending rank
        dodge=False
    )

    bar_ax.set_title("RICE Priority ▌Sorted Bar Chart", fontsize=14, pad=14)
    bar_ax.set_xlabel("Computed RICE Score", fontsize=11)
    bar_ax.set_ylabel(f"{category_name}", fontsize=11)

    # Add labels at the end of bars
    for i, v in enumerate(rice_df["Log_Normalized_RICE_Score"]):
        bar_ax.text(v + 0.05, i, f"{v:.2f}", va="center", fontsize=9)

    plt.tight_layout()
    plt.savefig(BARCHART_PNG, dpi=300)
    plt.close()
    print(f"[+] Bar chart saved ➤ {BARCHART_PNG.resolve()}")


# --- BAR CHART: Based on classification bucket ---
def generate_bar_chart_for_classification_bucket(file_path, category_name):
    BARCHART_PNG = OUT_DIR / f"{category_name}_bar_classification_bucket.png"
    df = pd.read_excel(file_path)

    # Fill all the missing values if there are any
    df['Classification_Bucket'] = df['Classification_Bucket'].fillna("Unclassified")
    df['Classification'] = df['Classification'].fillna("Unclassified")
    df['Count'] = 1

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x="Classification_Bucket", order=df["Classification_Bucket"].value_counts().index)
    plt.title("Proposal Count per Classification Bucket")
    plt.xlabel("Classification Bucket")
    plt.ylabel("Number of Proposals")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(BARCHART_PNG, dpi=300)
    plt.close()
    print(f"[+] Proposal Count per Classification Bucket Bar Chart written ➤ {BARCHART_PNG}")


# --- STACKED BAR CHART: Win/Loss per bucket ---
def generate_stacked_bar_chart(file_path, category_name):
    STACKED_BARCHART_PNG = OUT_DIR / f"{category_name}_stacked_bar.png"
    df = pd.read_excel(file_path)

    # Fill all the missing values if there are any
    df['Classification_Bucket'] = df['Classification_Bucket'].fillna("Unclassified")
    df['Classification'] = df['Classification'].fillna("Unclassified")
    df['Count'] = 1

    cross_tab = pd.crosstab(df["Classification_Bucket"], df["Outcome"])
    cross_tab.plot(kind="bar", stacked=True, figsize=(10, 6), colormap="Set2")
    plt.title("Proposal Win/Loss Distribution per Classification Bucket")
    plt.xlabel("Classification Bucket")
    plt.ylabel("Number of Proposals")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(STACKED_BARCHART_PNG, dpi=300)
    plt.close()
    print(f"[+] Proposal Win/Loss Distribution per Classification Bucket ➤ {STACKED_BARCHART_PNG.resolve()}")


# --- PIE CHART ---
def generate_pie_chart(file_path, category_name):
    PIECHART_PNG = OUT_DIR / f"{category_name}_pie_chart.png"
    df = pd.read_excel(file_path)

    # Fill all the missing values if there are any
    df['Classification_Bucket'] = df['Classification_Bucket'].fillna("Unclassified")
    df['Classification'] = df['Classification'].fillna("Unclassified")
    df['Count'] = 1

    bucket_counts = df["Classification_Bucket"].value_counts()
    plt.figure(figsize=(7, 7))
    plt.pie(bucket_counts, labels=bucket_counts.index, autopct="%1.1f%%", startangle=140)
    plt.title("Classification Bucket Distribution")
    plt.axis("equal")
    plt.tight_layout()
    plt.savefig(PIECHART_PNG, dpi=300)
    plt.close()
    print(f"[+] Proposal Win/Loss Distribution per Classification Bucket ➤ {PIECHART_PNG.resolve()}")


# --- TREE MAP with Hover ---
def generate_treemap_with_hover(file_path, category_name):
    TREEMAP_PNG = OUT_DIR / f"{category_name}_treemap.png"
    df = pd.read_excel(file_path)

    # Fill all the missing values if there are any
    df['Classification_Bucket'] = df['Classification_Bucket'].fillna("Unclassified")
    df['Classification'] = df['Classification'].fillna("Unclassified")
    df['Count'] = 1

    fig_treemap = px.treemap(
        df,
        path=["Classification_Bucket", "Classification"],
        values="Count",
        title="Proposal Classification Treemap",
        color="Classification_Bucket",
        custom_data=["Log_Normalized_RICE_Score", "TCS Positioning", "Geography", "Outcome"]
    )

    fig_treemap.update_traces(
        hovertemplate="<b>%{label}</b><br><br>" +
                      "RICE Score: %{customdata[0]:.2f}<br>" +
                      "TCS Positioning: %{customdata[1]}<br>" +
                      "Geography: %{customdata[2]}<br>" +
                      "Outcome: %{customdata[3]}<br>"
    )

    fig_treemap.update_layout(
        uniformtext=dict(minsize=14, mode="show")
    )

    pio.write_image(fig_treemap, TREEMAP_PNG, width=2000, height=1200)
    print(f"[+] Proposal Treemap ➤ {TREEMAP_PNG.resolve()}")


# --- SUNBURST ---
def generate_sunburst(file_path, category_name):
    SUNBURST_PNG = OUT_DIR / f"{category_name}_sunburst.png"
    df = pd.read_excel(file_path)

    # Fill all the missing values if there are any
    df['Classification_Bucket'] = df['Classification_Bucket'].fillna("Unclassified")
    df['Classification'] = df['Classification'].fillna("Unclassified")
    df['Count'] = 1

    fig_sunburst = px.sunburst(
        df,
        path=["Classification_Bucket", "Classification"],
        values="Count",
        title="Proposal Classification Sunburst",
        color="Classification_Bucket",
        custom_data=["Log_Normalized_RICE_Score", "TCS Positioning", "Geography", "Outcome"]
    )

    fig_sunburst.update_traces(
        hovertemplate="<b>%{label}</b><br><br>" +
                      "RICE Score: %{customdata[0]:.2f}<br>" +
                      "TCS Positioning: %{customdata[1]}<br>" +
                      "Geography: %{customdata[2]}<br>" +
                      "Outcome: %{customdata[3]}<br>"
    )

    fig_sunburst.update_layout(
        uniformtext=dict(minsize=14, mode="show")
    )

    pio.write_image(fig_sunburst, SUNBURST_PNG, width=2000, height=1200)
    print(f"[+] Proposal Treemap ➤ {SUNBURST_PNG.resolve()}")