import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path
from customer_charts import *
from proposal_classification_rules import classify_proposals

import json

# --- CONFIGURATION: DEFINE WEIGHTS (Strategic Business Decision) ---
# The weights for each RICE element's measures must sum to 1.0.
# NOTE: For this example, I've only listed a few measures per element for brevity.
# In your real implementation, you would list all 15+ measures and their weights.
weights = {
    'Reach': {
        'RCH01': 0.4, 'RCH06': 0.4, 'RCH03': 0.2  # Sum = 1.0
    },
    'Impact': {
        'IMP01': 0.5, 'IMP02': 0.3, 'IMP12': 0.2  # Sum = 1.0
    },
    'Confidence': {
        'CNF01': 0.3, 'CNF02': 0.3, 'CNF09': 0.4  # Sum = 1.0
    },
    'Effort': {
        'EFF01': 0.5, 'EFF05': 0.5  # Sum = 1.0
    }
}

# --- SAMPLE RAW DATA FOR 3 CUSTOMERS ---
# This data is on different scales (counts, dollars, 1–5 scores).
raw_data = {
    'CustomerID': ['Customer A', 'Customer B', 'Customer C'],
    
    # Reach Measures
    'RCH01': [5000, 500, 12000],          # Direct End-Users (raw count)
    'RCH06': [200000, 500000, 3500000],   # ARR (dollars)
    'RCH03': [5, 2, 8],                   # Departments (raw count)

    # Impact Measures (scored 1–5 by a human)
    'IMP01': [5, 3, 4],                   # Direct Cost Savings
    'IMP02': [2, 5, 3],                   # New Revenue Generation
    'IMP12': [2, 5, 3],                   # "Get in the Door" Opportunity

    # Confidence Measures (scored 1–5 by a human)
    'CNF01': [5, 3, 4],                   # Sponsor Influence
    'CNF02': [3, 4, 5],                   # Data Quality
    'CNF09': [4, 2, 5],                   # Partner Status

    # Effort Measures
    'EFF01': [12, 4, 24],                 # Person-Months (raw count)
    'EFF05': [8, 3, 9],                   # Technical Complexity (scored 1–10)
}

raw_df = pd.DataFrame(raw_data)

def standardize_measures(data_df, metadata_df):
    """
    STEP 1: Standardize all raw measures to a common 1–10 scale
    based on the MeasureType defined in the metadata. This is the 'Apples-to-Apples' step.
    """
    std_df = pd.DataFrame()
    std_df['ID'] = data_df['ID']
    
    std_df['Customer'] = data_df['Customer']
    std_df['Customer AI Maturity'] = data_df['Customer AI Maturity']
    std_df['TCS Positioning'] = data_df['TCS Positioning']
    std_df['Geography'] = data_df['Geography']
    std_df['Outcome'] = data_df['Outcome']

    # Iterate through each measure defined in the metadata
    for index, row in metadata_df.iterrows():
        measure_id = row['id']
        measure_type = row['type']

        if measure_id not in data_df.columns:
            # This check prevents an error crash in case a measure is in metadata but not in the data
            print(f"Warning: Measure {measure_id} from metadata not found in CustomerData sheet. Skipping standardization.")
            continue  # Skip if the measure is not in the data sheet

        # Apply logic for standardization based on the measure type from the metadata sheet
        # Types: Quantitative, Monetary ($), Qualitative Score (1–5), Percentage (%), Qualitative Score (1–10)

        if measure_type == "Quantitative":
            # Use pd.cut for binning quantitative data like user counts etc into a 1–10 scale
            std_df[measure_id] = pd.cut(data_df[measure_id], bins=4, labels=[1, 4, 7, 10], include_lowest=True)

        elif measure_type == "Monetary ($)":
            # Use pd.cut for binning monetary data like ARR (dollars) etc into a 1–10 scale
            std_df[measure_id] = pd.cut(data_df[measure_id], bins=4, labels=[1, 4, 7, 10], include_lowest=True)

        elif measure_type == "Qualitative Score (1–3)":
            # Map a 1–3 scale to a 1–10 scale
            std_df[measure_id] = 1 + ((data_df[measure_id] - 1) / 2) * 9

        elif measure_type == "Qualitative Score (1–5)":
            # Map a 1–5 scale to a 1–10 scale
            std_df[measure_id] = 1 + ((data_df[measure_id] - 1) / 4) * 9

        elif measure_type == "Percentage (%)":
            # Map a 0–100% scale to a 1–10 scale
            std_df[measure_id] = 1 + (data_df[measure_id] / 100) * 9

        elif measure_type == "Qualitative Score (1–10)":
            # Use the value directly if it is already on a target scale
            std_df[measure_id] = data_df[measure_id]

    # Convert all the columns to numeric
    for col in std_df.columns:
        if col not in ['ID', 'Customer', 'Customer AI Maturity', 'TCS Positioning', 'Geography', 'Outcome']:
            std_df[col] = pd.to_numeric(std_df[col])

    return std_df

def calculate_rice_scores_refined(data_df, metadata_df):
    """
    Calculates RICE scores using the data version, refined 3-step methodology.
    """

    # STEP 1: Standardize all raw measures to a common 1–10 scale
    std_df = standardize_measures(data_df, metadata_df)

    # Set the measure id as the index for easy lookup of weights and element
    metadata_df = metadata_df.set_index('id')

    # STEP 2: Calculate a single Composite Score for each RICE element
    composite_df = pd.DataFrame({
        'ID': std_df['ID'],
        'Customer': std_df['Customer'],
        'Customer AI Maturity': std_df['Customer AI Maturity'],
        'TCS Positioning': std_df['TCS Positioning'],
        'Geography': std_df['Geography'],
        'Outcome': std_df['Outcome']
    })

    rice_elements = ['Reach', 'Impact', 'Confidence', 'Effort']

    for element in rice_elements:
        composite_col_name = f'Composite_{element}'
        composite_df[composite_col_name] = 0

        # Get all the measures for the current element
        element_measures = metadata_df[metadata_df["element"] == element]

        for measure_id, measure_info in element_measures.iterrows():
            # Check if the measure exists in the standardized data before using it
            if measure_id in std_df.columns:
                weight = measure_info['weight']
                composite_df[composite_col_name] += std_df[measure_id] * weight
            # If it is not found it is silently skipped as the warning has already been printed in standardize_measures

    # STEP 3: Normalize the Composite Scores to a 1–100 scale
    norm_df = composite_df.copy()
    for element in rice_elements:
        composite_col = f'Composite_{element}'
        norm_col = f'Norm_{element}'

        min_val = norm_df[composite_col].min()
        max_val = norm_df[composite_col].max()

        if max_val == min_val:
            norm_df[norm_col] = 50.0  # Assign a neutral/mid score
        else:
            norm_df[norm_col] = 1 + ((norm_df[composite_col] - min_val) / (max_val - min_val)) * 99

    # --- FINAL RICE CALCULATION ---
    norm_df['RICE_Score'] = (norm_df['Norm_Reach'] * norm_df['Norm_Impact'] * norm_df['Norm_Confidence']) / norm_df['Norm_Effort']

    # --- NORMALIZE THE FINAL RICE SCORE: to a 1–100 scale ---
    min_rice = norm_df['RICE_Score'].min()
    max_rice = norm_df['RICE_Score'].max()
    if max_rice == min_rice:
        norm_df['Normalized_RICE_Score'] = 50
    else:
        norm_df['Normalized_RICE_Score'] = 1 + ((norm_df['RICE_Score'] - min_rice) / (max_rice - min_rice)) * 99

    # --- NORMALIZE THE FINAL RICE SCORE: Logarithmic Normalization (Better for outliers) ---
    # we use np.log1p which calculates log(1+x) to handle scores of 0 gracefully
    norm_df['Log_RICE_Score'] = np.log1p(norm_df['RICE_Score'])

    min_log_rice = norm_df['Log_RICE_Score'].min()
    max_log_rice = norm_df['Log_RICE_Score'].max()
    if min_log_rice == max_log_rice:
        norm_df['Log_Normalized_RICE_Score'] = 50.0
    else:
        norm_df['Log_Normalized_RICE_Score'] = 1 + ((norm_df['Log_RICE_Score'] - min_log_rice) / (max_log_rice - min_log_rice)) * 99

    # Sort by the final RICE score to get the ranking
    final_df = norm_df.sort_values(by='RICE_Score', ascending=False)

    return final_df


def convert_json_to_xslx():
    input_file_path = "measurement_criteria.json"
    content = ""

    with open(input_file_path, "r") as f:
        content = f.read()

    measurement = json.loads(content)
    criteria = measurement['riceFrameworkCriteria']
    print("———")
    for entry in criteria.get("Effort", []):
        print(entry["id"])
    print("———")
    for entry in criteria.get("Effort", []):
        print(entry["measure"])
    print("———")
    for entry in criteria.get("Effort", []):
        print(entry["description"])
    print("———")
    for entry in criteria.get("Effort", []):
        print(entry["type"])

def main(generate_excel: bool = False, generate_charts: bool = False, category_name: str = "default"):
    try:
        # Define the path to the input file
        input_file_path = f"{category_name}_rice_data.xlsx"

        # Read the data from the 'CustomerData' sheet
        data_df = pd.read_excel(input_file_path, sheet_name='Data')
        measures_metadata_df = pd.read_excel(input_file_path, sheet_name='MeasuresMetadata')

        # --- RUN THE ENTIRE WORKFLOW ---
        final_scores_df = calculate_rice_scores_refined(data_df, measures_metadata_df)

        # Round all the numeric columns in the DataFrame to 2 decimal places
        final_scores_df = final_scores_df.round(2)

        # --- Classify the proposals ---
        classification_display_cols = [
            'ID',
            'Customer',
            'Customer AI Maturity',
            'TCS Positioning',
            'Geography',
            'Outcome',
            'Log_Normalized_RICE_Score',
            'Classification_Bucket',
            'Classification',
            'Explanation'
        ]

        classified_df = classify_proposals(final_scores_df)
        print(classified_df[classification_display_cols])

        # --- DISPLAY THE FINAL, RANKED RESULTS ---
        display_cols = [
            'ID',
            'Norm_Reach',
            'Norm_Impact',
            'Norm_Confidence',
            'Norm_Effort',
            'RICE_Score',
            'Normalized_RICE_Score',
            'Log_Normalized_RICE_Score'
        ]

        print("--- Final RICE Scores and Ranking ---")
        print(final_scores_df[display_cols])

        # optional write to excel
        if generate_excel:
            OUT_DIR = Path("./output")
            EXCEL_OUT = OUT_DIR / f"{category_name}_rice_matrix_scoring.xlsx"
            EXCEL_OUT_REASONING = OUT_DIR / f"{category_name}_win_loss_reasoning.xlsx"

            with pd.ExcelWriter(EXCEL_OUT, engine="openpyxl") as writer:
                final_scores_df[display_cols].to_excel(writer, sheet_name="Sorted RICE Priorities", index=False)

            with pd.ExcelWriter(EXCEL_OUT_REASONING, engine="openpyxl") as writer:
                classified_df[classification_display_cols].to_excel(writer, sheet_name="Proposal Analysis", index=False)

            print(f"[+] Excel written ➤ {EXCEL_OUT.resolve()}")
            print(f"[+] Excel written ➤ {EXCEL_OUT_REASONING.resolve()}")

        # generate the heatmap
        if generate_charts:
            # Generate the RICE based Heatmap for customers
            generate_heatmap_chart(final_scores_df, category_name)

            # Plot Horizontal Bar Chart for customers
            generate_bar_chart(final_scores_df, category_name)

            generate_bar_chart_for_classification_bucket(EXCEL_OUT_REASONING.resolve(), category_name)
            generate_stacked_bar_chart(EXCEL_OUT_REASONING.resolve(), category_name)
            generate_pie_chart(EXCEL_OUT_REASONING.resolve(), category_name)
            generate_treemap_with_hover(EXCEL_OUT_REASONING.resolve(), category_name)
            generate_sunburst(EXCEL_OUT_REASONING.resolve(), category_name)

    except FileNotFoundError:
        print(f"ERROR: The file '{category_name}_rice_data.xlsx' was not found")
        print("Please make sure the Excel file is in the same directory as the script.")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# --- RUN THE ENTIRE WORKFLOW ---
if __name__ == "__main__":
    main(generate_excel=True, generate_charts=True, category_name="proposal")  # run the entire workflow




