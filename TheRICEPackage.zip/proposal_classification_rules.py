import pandas as pd
from typing import List, Dict

# Define Rule structure
Rule = Dict[str, any]

# Step 1: Define classification rules
rules: List[Rule] = [
    # Strategic Success
    {
        "name": "Strategic Alignment Win",
        "bucket": "Strategic Success",
        "outcome": "Win",
        "description": "High alignment with strategic priorities and vendor preference.",
        "condition": lambda r: r["Log_Normalized_RICE_Score"] > 75 and r["Norm_Impact"] > 75 and r["Norm_Confidence"] > 75 and r["Norm_Effort"] <= 60 and r["TCS Positioning"] in ['Preferred', 'Primary']
    },
    {
        "name": "CxO Driven Win",
        "bucket": "Strategic Success",
        "outcome": "Win",
        "description": "High Norm_Impact and strategic alignment with C-Level agenda.",
        "condition": lambda r: r["Norm_Impact"] > 80 and r["Norm_Confidence"] > 70 and r["Customer AI Maturity"] in ["Adopter", "Leader"]
    },
    {
        "name": "Cross-BU Scalability Win",
        "bucket": "Strategic Success",
        "outcome": "Win",
        "description": "Proposal had high potential to scale across customer business units.",
        "condition": lambda r: r["Log_Normalized_RICE_Score"] > 70 and r["Norm_Impact"] > 70 and r["Customer AI Maturity"] == "Leader"
    },
    {
        "name": "Primary Vendor Preference Win",
        "bucket": "Strategic Success",
        "outcome": "Win",
        "description": "Win supported by customer's existing preference for the vendor.",
        "condition": lambda r: r["TCS Positioning"] == "Primary" and r["Norm_Confidence"] > 60
    },

    # Innovation & First-Mover Advantage
    {
        "name": "Innovation-Led Win",
        "bucket": "Innovation & First-Mover Advantage",
        "outcome": "Win",
        "description": "Won due to novel GenAI approach and early adopter interest.",
        "condition": lambda r: r["Norm_Impact"] > 85 and r["Customer AI Maturity"] == "Explorer"
    },
    {
        "name": "Quick-Win Prototype Win",
        "bucket": "Innovation & First-Mover Advantage",
        "outcome": "Win",
        "description": "Low Norm_Effort, medium Log_Normalized_RICE_Score and Norm_Impact — likely a quick prototype.",
        "condition": lambda r: r["Log_Normalized_RICE_Score"] > 40 and r["Norm_Impact"] > 40 and r["Norm_Effort"] < 50
    },
    {
        "name": "GenAI Showcase Win",
        "bucket": "Innovation & First-Mover Advantage",
        "outcome": "Win",
        "description": "Proposal included GenAI showcase with LLM or CoPilot integration.",
        "condition": lambda r: r["Norm_Impact"] > 70 and r["Norm_Confidence"] > 70 and r["Norm_Effort"] < 60
    },
    {
        "name": "Low Effort Win",
        "bucket": "Innovation & First-Mover Advantage",
        "outcome": "Win",
        "description": "Won due to very low effort and acceptable business value.",
        "condition": lambda r: r["Norm_Impact"] > 30 and r["Norm_Effort"] < 5
    },

    # Relationship & Legacy Advantage
    {
        "name": "Relationship Win",
        "bucket": "Relationship & Legacy Advantage",
        "outcome": "Win",
        "description": "Won despite low score due to preferred vendor relationship.",
        "condition": lambda r: r["RICE_Score"] < 60 and r["TCS Positioning"] in ["Preferred", "Primary"]
    },
    {
        "name": "Incumbent Win",
        "bucket": "Relationship & Legacy Advantage",
        "outcome": "Win",
        "description": "Vendor has strong delivery history or prior engagement.",
        "condition": lambda r: r["Norm_Confidence"] > 70 and r["TCS Positioning"] == "Preferred"
    },
    {
        "name": "Legacy System Familiarity Win",
        "bucket": "Relationship & Legacy Advantage",
        "outcome": "Win",
        "description": "Proposal was successful due to deep knowledge of client legacy systems.",
        "condition": lambda r: r["Norm_Confidence"] > 65 and r["Norm_Effort"] <= 70
    },

    # Low scoring, weak on Reach/Impact/Confidence, sometimes having high effort too, but still winning, outlier
    {
        "name": "Low Score Opportunistic Win",
        "bucket": "Relationship & Legacy Advantage",
        "outcome": "Win",
        "description": "Proposal likely won due to non-scoring factors like bundling, urgency from customer or political alignment.",
        "condition": lambda r: r["Log_Normalized_RICE_Score"] < 10 and r["TCS Positioning"] in ["Primary", "Secondary"]
    },

    # Execution or Value Gaps
    {
        "name": "Execution Risk Loss",
        "bucket": "Execution or Value Gaps",
        "outcome": "Loss",
        "description": "Low Norm_Confidence and high Norm_Effort raised delivery concerns.",
        "condition": lambda r: r["Norm_Confidence"] < 50 and r["Norm_Effort"] > 75
    },
    {
        "name": "Unclear ROI Loss",
        "bucket": "Execution or Value Gaps",
        "outcome": "Loss",
        "description": "Proposal lacked strong business case or clear ROI.",
        "condition": lambda r: r["Norm_Impact"] < 50
    },
    {
        "name": "Overengineered Loss",
        "bucket": "Execution or Value Gaps",
        "outcome": "Loss",
        "description": "Proposal was too complex for its business value.",
        "condition": lambda r: r["Norm_Effort"] > 75 and (r["Log_Normalized_RICE_Score"] + r["Norm_Impact"]) / 2 < 60
    },
    {
        "name": "Poor Fit Loss",
        "bucket": "Execution or Value Gaps",
        "outcome": "Loss",
        "description": "Proposal did not address the key user group or geography.",
        "condition": lambda r: r["Log_Normalized_RICE_Score"] < 40
    },
    {
        "name": "Mismatch with AI Maturity Loss",
        "bucket": "Execution or Value Gaps",
        "outcome": "Loss",
        "description": "Proposal ambition exceeded customer's AI readiness.",
        "condition": lambda r: r["Customer AI Maturity"] == "Explorer" and r["Norm_Effort"] > 70
    },

    # Competitive & Commercial Pressure
    {
        "name": "Pricing Mismatch Loss",
        "bucket": "Competitive & Commercial Pressure",
        "outcome": "Loss",
        "description": "Strong proposal but lost due to pricing in sensitive region.",
        "condition": lambda r: r["RICE_Score"] > 80 and r["Geography"] in ["APAC", "South America"]
    },
    {
        "name": "Competitor Undercut Loss",
        "bucket": "Competitive & Commercial Pressure",
        "outcome": "Loss",
        "description": "Strong proposal lost to faster or more agile competitor.",
        "condition": lambda r: r["RICE_Score"] > 80 and r["Norm_Confidence"] > 75
    },
    {
        "name": "Positioning Disadvantage Loss",
        "bucket": "Competitive & Commercial Pressure",
        "outcome": "Loss",
        "description": "Lost due to not being preferred/primary vendor.",
        "condition": lambda r: r["TCS Positioning"] not in ["Preferred", "Primary"] and r["Norm_Confidence"] > 60
    },
    {
        "name": "Loss Despite High Score",
        "bucket": "Competitive & Commercial Pressure",
        "outcome": "Loss",
        "description": "High RICE score but still lost; suggests commercial/strategic mismatch.",
        "condition": lambda r: r["RICE_Score"] > 80
    }
]

# Step 2: Apply classification
def classify_proposals(df: pd.DataFrame) -> pd.DataFrame:
    def classify(row):
        for rule in rules:
            if row["Outcome"] == rule["outcome"] and rule["condition"](row):
                return pd.Series([rule["bucket"], rule["name"], rule["description"]])
        return pd.Series(["Unclassified", "Unclassified", "No matching rule found."])

    # df["RICE_Score"] = (df["Reach"] * df["Impact"] * df["Confidence"]) / df["Effort"]
    df[["Classification_Bucket", "Classification", "Explanation"]] = df.apply(classify, axis=1, result_type="expand")
    return df
